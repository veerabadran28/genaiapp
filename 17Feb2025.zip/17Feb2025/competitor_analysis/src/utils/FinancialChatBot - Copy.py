import streamlit as st
from typing import Dict, List
import pandas as pd
import json
import re

class FinancialChatBot:
    def __init__(self, datasets: Dict[str, pd.DataFrame], model_response: Dict, bank_info: Dict, bedrock_service, additional_docs: Dict = None):
        self.datasets = datasets
        self.model_response = model_response
        self.bank_info = bank_info
        self.bedrock_service = bedrock_service
        self.additional_docs = additional_docs or {}
        self.greetings = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening']
        self.context = None

    def _is_greeting(self, text: str) -> bool:
        """Check if the input is a greeting."""
        return any(greeting in text.lower() for greeting in self.greetings)

    def _get_greeting_response(self) -> Dict:
        """Get appropriate greeting response."""
        return {
            'response': f"Hello! I'm your financial analysis assistant for {self.bank_info.get('name')}. I can help you understand the financial metrics and KPIs in the processed data. What would you like to know about?",
            'follow_up': [
                "You can ask about:",
                "- Latest financial performance",
                "- Key metrics comparison",
                "- Balance sheet analysis"
            ],
            'type': 'greeting'
        }

    def _find_relevant_info(self, query: str) -> List[Dict]:
        """Find strictly relevant information from data sources."""
        if self._is_greeting(query):
            return []

        relevant_info = []
        query_terms = query.lower().split()
        
        # Search in model response data
        if 'data' in self.model_response:
            for row in self.model_response['data']:
                if len(row) > 1:
                    row_str = ' '.join(str(x) for x in row).lower()
                    if any(term in row_str for term in query_terms):
                        relevant_info.append({
                            'source': 'Model Analysis',
                            'data': row,
                            'type': 'analysis',
                            'confidence': 'high' if all(term in row_str for term in query_terms) else 'medium'
                        })
        
        # Search in datasets
        for dataset_name, df in self.datasets.items():
            for col in df.columns:
                col_lower = col.lower()
                if any(term in col_lower for term in query_terms):
                    row_data = df[col].to_dict()
                    relevant_info.append({
                        'source': f"{dataset_name} - {col}",
                        'data': row_data,
                        'type': 'metric',
                        'confidence': 'high' if all(term in col_lower for term in query_terms) else 'medium'
                    })

        return relevant_info

    def _prepare_claude_prompt(self, query: str, relevant_info: List[Dict]) -> str:
        """Prepare a prompt for Claude with context and query."""
        prompt = f"""You are a financial analyst assistant for {self.bank_info.get('name')}. 
        Answer questions about financial data in a concise, human-like way.
        
        Here's the relevant financial data:
        """
        
        # Add data context
        for info in relevant_info:
            if info['type'] == 'analysis':
                prompt += f"\nMetric data: {info['data']}"
            elif info['type'] == 'metric':
                prompt += f"\nTime series data:\n"
                for period, value in info['data'].items():
                    prompt += f"{period}: {value}\n"

        prompt += f"\nQuestion: {query}\n"
        prompt += """
        Provide a concise, human-like response that:
        1. Directly answers the question
        2. Explains any significant changes or trends if relevant
        3. Keep the explanation brief and focused
        
        Format the response as a JSON object with these fields:
        {
            "response": "your concise response here",
            "follow_up": ["relevant follow-up question 1", "relevant follow-up question 2"],
            "type": "data_response"
        }
        """

        return prompt

    def get_response(self, query: str) -> Dict:
        """Generate response using Bedrock Claude."""
        if self._is_greeting(query):
            return self._get_greeting_response()

        # Find relevant information
        relevant_info = self._find_relevant_info(query)
        
        if not relevant_info:
            return {
                'response': "I couldn't find specific information about that in the data. Could you please be more specific?",
                'follow_up': [
                    "You can ask about:",
                    "- Net Interest Income (NII)",
                    "- Balance Sheet metrics",
                    "- Performance ratios"
                ],
                'type': 'clarification'
            }

        try:
            # Prepare and send prompt to Claude
            prompt = self._prepare_claude_prompt(query, relevant_info)
            claude_response = self.bedrock_service.invoke_model(prompt)
            
            if claude_response and 'response' in claude_response:
                return claude_response
            else:
                # Fallback response if Claude fails
                return {
                    'response': "I understand you're asking about " + query + ", but I'm having trouble processing the response. Could you try rephrasing your question?",
                    'follow_up': [
                        "Try asking about:",
                        "- Specific time periods",
                        "- Particular metrics",
                        "- Year-over-year changes"
                    ],
                    'type': 'error'
                }
                
        except Exception as e:
            st.error(f"Error processing response: {str(e)}")
            return {
                'response': "I apologize, but I'm having trouble analyzing the data right now. Please try again.",
                'follow_up': [
                    "In the meantime, you can:",
                    "- Try a different question",
                    "- Ask about another metric",
                    "- Check the raw data in the tables above"
                ],
                'type': 'error'
            }

    def render_chat_interface(self):
        """Render the chat interface."""
        st.markdown("""
            <style>
            .chat-container {
                position: fixed;
                bottom: 0;
                right: 20px;
                width: 350px;  /* Slightly wider for better readability */
                background-color: white;
                border: 1px solid #ddd;
                border-radius: 10px 10px 0 0;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
                z-index: 1000;
                display: flex;
                flex-direction: column;
                max-height: 50px;  /* Set maximum height */
            }
            .chat-header {
                background-color: #0051A2;
                color: white;
                padding: 10px;
                border-radius: 10px 10px 0 0;
                font-weight: bold;
                flex-shrink: 0;  /* Prevent header from shrinking */
            }
            .chat-body {
                flex-grow: 1;  /* Allow body to grow */
                overflow-y: auto;  /* Enable scrolling */
                padding: 10px;
                background-color: #f8f9fa;
                min-height: 300px;  /* Minimum height */
                max-height: 400px;  /* Maximum height */
                display: flex;
                flex-direction: column;
            }
            .chat-input-area {
                padding: 10px;
                background-color: white;
                border-top: 1px solid #ddd;
                flex-shrink: 0;  /* Prevent input area from shrinking */
            }
            .chat-message {
                margin: 8px 0;
                padding: 8px;
                border-radius: 4px;
                max-width: 85%;
                word-wrap: break-word;
            }
            .user-message {
                background-color: #e3f2fd;
                margin-left: 15%;
                align-self: flex-end;
            }
            .bot-message {
                background-color: white;
                margin-right: 15%;
                border: 1px solid #ddd;
                align-self: flex-start;
            }
            .follow-up {
                font-size: 0.9em;
                color: #666;
                margin-top: 5px;
                padding-top: 5px;
                border-top: 1px solid #eee;
            }
            /* Hide Streamlit elements we don't want to see */
            .stTextInput > div > div > input {
                background-color: white;
                max-width: 100%;
            }
            .stTextInput > div {
                padding: 0;
            }
            .stTextInput > label {
                display: none;
            }
            </style>
        """, unsafe_allow_html=True)

         # Initialize chat states
        if "chat_history" not in st.session_state:
            st.session_state.chat_history = []
            # Add initial greeting
            greeting_response = self._get_greeting_response()
            st.session_state.chat_history.append({
                "role": "assistant",
                "content": greeting_response['response'],
                "follow_up": greeting_response['follow_up']
            })

        # Initialize message state
        if "message" not in st.session_state:
            st.session_state.message = ""

        chat_container = st.container()
        with chat_container:
            #st.markdown('<div class="chat-container">', unsafe_allow_html=True)
            
            # Chat header
            st.markdown('<div class="chat-header">Financial Analysis Assistant', unsafe_allow_html=True)
            
            # Chat body
            #st.markdown('<div class="chat-body">', unsafe_allow_html=True)
            for message in st.session_state.chat_history:
                if message["role"] == "user":
                    st.markdown(f'<div class="chat-message user-message">🤵 {message["content"]}</div>', 
                            unsafe_allow_html=True)
                else:
                    st.markdown(f'<div class="chat-message bot-message">🤖 {message["content"]}', 
                            unsafe_allow_html=True)
                    if "follow_up" in message:
                        st.markdown(f'<div class="follow-up">{chr(10).join(message["follow_up"])}</div>', 
                                unsafe_allow_html=True)
                    st.markdown('</div>', unsafe_allow_html=True)
            
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Chat input
            with st.container():
                # Initialize input state
                if "user_input" not in st.session_state:
                    st.session_state.user_input = ""

                def submit():
                    if st.session_state.chat_input.strip():
                        # Get the input value
                        user_message = st.session_state.chat_input
                        
                        # Add user message to history
                        st.session_state.chat_history.append({
                            "role": "user",
                            "content": user_message
                        })
                        
                        # Get bot response
                        response_data = self.get_response(user_message)
                        
                        # Add bot response to history
                        st.session_state.chat_history.append({
                            "role": "assistant",
                            "content": response_data['response'],
                            "follow_up": response_data['follow_up']
                        })
                        
                        # Clear the input by setting session state
                        st.session_state.user_input = ""
                        st.session_state.chat_input = ""

                # Text input with submit handler
                st.text_input(
                    "Ask about the financial data:",
                    key="chat_input",
                    on_change=submit,
                    value=st.session_state.user_input
                )