import boto3
from typing import Dict, List
import json
from datetime import datetime
import uuid

class ChatHistory:
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb')
        self.table = self.dynamodb.Table('document_chat_history')

    def store_chat(self, document_path: str, messages: List[Dict]):
        """Store chat messages in DynamoDB."""
        try:
            chat_id = str(uuid.uuid4())
            timestamp = datetime.utcnow().isoformat()
            
            item = {
                'chat_id': chat_id,
                'document_path': document_path,
                'timestamp': timestamp,
                'messages': messages
            }
            
            self.table.put_item(Item=item)
            
        except Exception as e:
            raise Exception(f"Error storing chat history: {str(e)}")

    def get_chat_history(self, document_path: str) -> List[Dict]:
        """Get chat history for a document."""
        try:
            response = self.table.query(
                IndexName='document_path-timestamp-index',
                KeyConditionExpression='document_path = :path',
                ExpressionAttributeValues={
                    ':path': document_path
                }
            )
            
            # Sort by timestamp
            items = sorted(response['Items'], key=lambda x: x['timestamp'])
            
            return items
            
        except Exception as e:
            raise Exception(f"Error getting chat history: {str(e)}")

    def delete_chat_history(self, document_path: str):
        """Delete chat history for a document."""
        try:
            # Get all chat IDs for the document
            history = self.get_chat_history(document_path)
            
            # Delete each chat record
            for chat in history:
                self.table.delete_item(
                    Key={
                        'chat_id': chat['chat_id']
                    }
                )
                
        except Exception as e:
            raise Exception(f"Error deleting chat history: {str(e)}")