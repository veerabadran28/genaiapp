import streamlit as st
import pandas as pd
import os
import time
from typing import Dict, Optional
import json
import boto3
import io
import base64
import unicodedata
from src.utils.FinancialChatBot import FinancialChatBot
from src.services.s3_service import S3Service
from src.utils.pdf_processor import PDFProcessor

class SummaryAnalysisUI:
    def __init__(self, common_config: Dict, bank_configs: Dict, bedrock_service):
        self.common_config = common_config
        self.bank_configs = bank_configs
        self.bedrock_service = bedrock_service
        # Get driver values from session state
        self.driver_values = st.session_state.get('driver_values', {})

    def render(self):
        """Render the Summary Analysis interface."""
        # Apply static styling
        st.markdown("""
            <style>
            .stButton > button {
                background-color: #0051A2;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                cursor: pointer;
            }
            .section-header {
                background-color: #006A4D;
                color: white;
                padding: 10px 15px;
                margin-bottom: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            .dataframe th {
                background-color: #006A4D !important;
                color: white !important;
                text-align: center !important;
            }
            .dataframe td {
                padding: 8px !important;
            }
            .stTabs [data-baseweb="tab"] {
                background-color: #f8f9fa;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            .stTabs [data-baseweb="tab"][aria-selected="true"] {
                background-color: #0051A2 !important;
                color: white !important;
            }
            </style>
        """, unsafe_allow_html=True)

        # Render header
        col1, col2, col3 = st.columns([0.1, 10.5, 1])
        with col2:
            st.markdown("### Summary Analysis")
        with col3:
            if st.button("← Back", key="summary_back", use_container_width=True):
                st.session_state.current_view = 'main'
                st.rerun()

        # Main tabs from config
        main_tabs = st.tabs(self.common_config['tabs_config']['main_tabs'])

        with main_tabs[0]:  # Final Summary
            self._render_final_summary()

        with main_tabs[1]:  # Working Summary
            self._render_working_summary()

    def _render_working_summary(self):
        """Render Working Summary section using working_summary_tabs from config."""
        # Get tabs from config
        working_summary_tabs = self.common_config['tabs_config']['working_summary_tabs']
        tabs = st.tabs(working_summary_tabs)

        for bank_name, tab in zip(working_summary_tabs, tabs):
            with tab:
                bank_id = self._get_bank_id(bank_name)
                bank_config = self.bank_configs.get(bank_id)
                print(bank_config['bank_info'].get('implementation_status'))
                if bank_config and bank_config['bank_info'].get('implementation_status') == 'active':
                    st.session_state.selected_bank = bank_id
                    self._render_bank_analysis(bank_config)
                else:
                    st.info(f"Implementation pending for {bank_name}")

    def _construct_filename(self, file_pattern: str) -> str:
        """Construct filename using driver values and pattern."""
        try:
            # Get all necessary values from driver_values
            full_year = st.session_state.get('driver_year', '')
            year_last_two_digit = full_year[-2:] if full_year else ''
            quarter_period_lower = self.driver_values.get("Quarter End Results Period", "").lower()
            quarter_period_caps = self.driver_values.get("Quarter End Results Period", "")
            quarter_period_year = self.driver_values.get("Quarter End Results Period Year", "")
            prior_quarter_period_caps = self.driver_values.get("Prior Quarter End Results Period", "")[:2]
            prior_quarter_end_year = self.driver_values.get("Prior Quarter End Results Period Year", "")
            half_year_period_lower = self.driver_values.get("Half Year End Results Period", "").lower()
            half_year_period_caps = self.driver_values.get("Half Year End Results Period", "")            

            # Set period constants
            if half_year_period_lower == "h1":
                period_const_lower = 'hy'
                period_const_caps = 'HY'
            elif half_year_period_lower == "h2":
                period_const_lower = 'fy'
                period_const_caps = 'FY'
            else:
                period_const_lower = ''
                period_const_caps = ''

            # Replace placeholders in pattern
            filename = file_pattern.format(
                full_year=full_year,
                year_last_two_digit=year_last_two_digit,
                quarter_period_lower=quarter_period_lower,
                quarter_period_caps=quarter_period_caps,
                quarter_period_year=quarter_period_year,
                prior_quarter_period_caps=prior_quarter_period_caps,
                prior_quarter_end_year=prior_quarter_end_year,
                half_year_period_lower=half_year_period_lower,
                half_year_period_caps=half_year_period_caps,
                period_const_lower=period_const_lower,
                period_const_caps=period_const_caps
            )
            print(f"filename:{filename}")
            return filename

        except Exception as e:
            st.error(f"Error constructing filename: {str(e)}")
            return None
    
    def _construct_s3_uri(self, bank_name: str, file_pattern: str = None, file_config: Dict = None) -> str:
        """
        Construct complete S3 URI using driver values and bank name.
        
        Args:
            bank_name: Name of the bank
            file_pattern: Pattern for the filename
            file_config: Configuration for the specific file
        """
        try:
            if not self.driver_values:
                st.error("No driver values available")
                return None
                
            bucket = self.common_config['s3_config']['bucket']
            main_folder = self.common_config['s3_config']['main_folder']
            
            # Determine which period to use based on file config
            if file_config and 'period_type' in file_config:
                # Use the period type specified in config
                period_template = file_config.get('period_type')
                # Replace placeholders in period_type with actual values
                period = period_template.format(
                    quarter_period_caps=self.driver_values.get("Quarter End Results Period"),
                    prior_quarter_period_caps=self.driver_values.get("Prior Quarter End Results Period"),
                )
            else:
                # Default to Quarter End Results Period for backward compatibility
                period = self.driver_values.get("Quarter End Results Period")
            
            print(f"period:{period}")
            if not period:
                st.error("Period not found in driver values")
                return None
                
            # Determine which year to use
            if file_config and 'period_year' in file_config:
                # Use the year specified in config
                year_template = file_config.get('period_year')
                # Replace placeholders in period_year with actual values
                year = year_template.format(
                    quarter_period_year=self.driver_values.get("Quarter End Results Period Year"),
                    prior_quarter_end_year=self.driver_values.get("Prior Quarter End Results Period Year")
                )
            else:
                # Default to session state year for backward compatibility
                year = self.driver_values.get("Quarter End Results Period Year")
                
            if not year:
                st.error("No year found")
                return None
            print(f"year:{year}")
            
            # Clean bank name for S3 path
            bank_folder = bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            
            # Construct base S3 URI with period-specific folder
            s3_uri = f"s3://{bucket}/{main_folder}/{bank_folder}/{year}/{period}"
            
            # If file pattern is provided, construct and append filename
            if file_pattern:
                filename = self._construct_filename(file_pattern)
                if filename:
                    s3_uri = f"{s3_uri}/{filename}"
                print(f"s3_uri:{s3_uri}")
            return s3_uri
            
        except Exception as e:
            st.error(f"Error constructing S3 URI: {str(e)}")
            return None
    
    def _process_json_file(self, s3_uri: str, sections: list) -> dict:
        """Fetch and process a JSON file from S3."""
        try:
            s3_service = S3Service(self.common_config['s3_config'])
            file_content = s3_service.get_document_content(s3_uri)

            if not file_content:
                st.error(f"No content found for S3 URI: {s3_uri}")
                return {}

            json_data = json.loads(file_content.decode('utf-8'))
            processed_data = {}

            for section in sections:
                data_key = section.get('data_key')
                if data_key and data_key in json_data:
                    processed_data[data_key] = json_data[data_key]
                else:
                    st.warning(f"Data key '{data_key}' not found in JSON data.")

            return processed_data

        except Exception as e:
            st.error(f"Error processing JSON file: {str(e)}")
            return {}
    
    def _render_bank_analysis(self, bank_config: Dict):
        """Render bank analysis section."""
        try:
            # Get bank ID
            bank_id = bank_config['bank_info']['name'].lower().replace(' ', '_')
            tab_name = bank_config['bank_info']['tab_name'].lower().replace(' ', '_')
            print(f"inside tab:{tab_name}")
            # Check for cached response first
            cached_response = self._get_cached_response(
                bank_config['bank_info']['name'],
                bank_config['bank_info']['tab_name'],
                st.session_state.driver_year,
                st.session_state.driver_period
            )

            # If we have cached response, initialize session state and display data
            if cached_response:
                print(f"Received cached response for tab:{tab_name}")
                dataset_configs = bank_config.get('datasets', {})
                datasets = self.parse_datasets(cached_response, dataset_configs)
                
                # Update session state with cached data
                st.session_state[f"datasets_{tab_name}"] = datasets
                st.session_state[f"json_response_{tab_name}"] = cached_response
                st.session_state[f"data_processed_{tab_name}"] = True

                # Render layout with cached data
                self._render_layout(bank_config, tab_name, None)
                return

            # If no cache, proceed with file processing
            file_configs = bank_config['file_config']['files']
            if not file_configs:
                st.error("No file configuration found")
                return

            # Initialize cleaned_df and formatted_data_dict
            cleaned_df = pd.DataFrame()
            formatted_data_dict = {}

            for file_config in file_configs:
                
                file_type = file_config.get('file_type')
                s3_uri = file_config.get('s3_uri')
            
                # Get file pattern
                file_pattern = file_config.get('file_pattern')
                if not file_pattern:
                    st.error("File pattern not found in configuration")
                    continue                
                
                if s3_uri:
                    full_s3_path = s3_uri
                else:
                    # Construct S3 URI for this file
                    full_s3_path = self._construct_s3_uri(
                        bank_config['bank_info']['name'],
                        file_pattern=file_pattern,
                        file_config=file_config
                    )

                print(f"full_s3_path:{full_s3_path}")
                if not full_s3_path:
                    st.error(f"Failed to construct S3 URI for file pattern: {file_pattern}")
                    continue

                try:
                    # Initialize S3 service and get content
                    s3_service = S3Service(self.common_config['s3_config'])
                    file_content = s3_service.get_document_content(full_s3_path)
                    
                    if file_type == "json":
                        json_data = json.loads(file_content.decode('utf-8'))
                        data_key = file_config.get('data_key')
                        formatted_data_dict[data_key] = json_data
                    elif file_type == "pdf":
                        # Handle PDF files
                        pdf_processor = PDFProcessor(file_content)
                        pdf_data = pdf_processor.process_sections(file_config.get('sections', []))
                        formatted_data_dict.update(pdf_data)
                    else:
                        # Handle Excel files
                        excel_file = io.BytesIO(file_content)
                        if 'sheets' in file_config:
                            # Process multiple sheets
                            for sheet_config in file_config['sheets']:
                                sheet_name = sheet_config['sheet_name']
                                data_key = sheet_config['data_key']
                                try:
                                    sheet_data = pd.read_excel(excel_file, sheet_name=sheet_name)
                                    temp_cleaned_data = sheet_data.dropna(how="all")
                                    temp_cleaned_data = temp_cleaned_data.dropna(how="all", axis=1)
                                    formatted_data_dict[data_key] = temp_cleaned_data.to_string(index=False)
                                except Exception as e:
                                    st.error(f"Error reading sheet {sheet_name}: {str(e)}")

                except Exception as e:
                    st.error(f"Error reading file from S3: {str(e)}")
                    continue

            # Render layout with processed data
            self._render_layout(bank_config, tab_name, formatted_data_dict)

        except Exception as e:
            st.error(f"Error: {str(e)}")
            st.exception(e)

    def _render_layout(self, bank_config: Dict, tab_name: str, formatted_data_dict: Dict = None):
        """Render the layout with either cached or processed data."""
        # Layout columns for main content and sidebar
        col1, col2, col3 = st.columns([0.00001, 2.5, 1])
        
        # Sidebar with logo and chatbot
        with col3:
            st.image(bank_config['bank_info']['logo_url'], width=200)
            desc_container = st.container(border=True)
            desc_container.write(bank_config['bank_info'].get('description', ''))
            
            # Add chatbot if data is processed
            if (st.session_state.get(f"datasets_{tab_name}") is not None and 
                st.session_state.get(f"json_response_{tab_name}") is not None):
                try:
                    combined_data1 = []
                    
                    for dataset_name, df in st.session_state[f"datasets_{tab_name}"].items():
                        if not df.empty:
                            combined_data1.append([dataset_name])
                            combined_data1.append(list(df.columns))
                            combined_data1.extend(df.values.tolist())
                            combined_data1.append([])

                    combined_df1 = pd.DataFrame(combined_data1)
                    chatbot = FinancialChatBot(
                        datasets={'combined': combined_df1},
                        model_response={},
                        bank_info=bank_config['bank_info'],
                        bedrock_service=self.bedrock_service
                    )
                    chatbot.render_chat_interface()
                except Exception as e:
                    st.error(f"Error initializing chatbot: {str(e)}")
        
        # Main content area
        with col2:
            tab1, tab2 = st.tabs(self.common_config['tabs_config']['main_view_tabs'])
            
            # Summary Tab
            with tab1:
                self._render_summary_tab(pd.DataFrame(), bank_config, formatted_data_dict)

            # Data Preview Tab
            with tab2:
                self._render_data_preview(bank_config['file_config']['files'], bank_config)

        # Footer
        st.markdown("<hr style='margin: 15px 0px; border: 1px solid #00b8e6'>", unsafe_allow_html=True)
        st.markdown(
            "<div style='text-align: center; color: #666666;'>Competitor Analysis | Powered by AWS Bedrock Claude 3.5 Sonnet</div>",
            unsafe_allow_html=True
        )

    def _render_data_preview(self, file_configs, bank_config):
        """Render data preview section."""
        s3_service = S3Service(self.common_config['s3_config'])
        st.markdown("### Raw Data Preview")

        # Ensure file_configs is a list
        if not isinstance(file_configs, list):
            file_configs = [file_configs]

        # Create tabs for each file
        file_tabs = st.tabs([
            self._construct_filename(file_config.get('file_pattern', f'File {i+1}'))
            for i, file_config in enumerate(file_configs)
        ])
        
        for tab, file_config in zip(file_tabs, file_configs):
            with tab:
                try:
                    file_type = file_config.get('file_type')
                    s3_uri = file_config.get('s3_uri')

                    if s3_uri:
                        current_file_path = s3_uri
                    else:
                        # Construct file path for each file
                        current_file_path = self._construct_s3_uri(
                            bank_config['bank_info']['name'],
                            file_pattern=file_config.get('file_pattern'),
                            file_config=file_config
                        )

                    # Get file content based on type
                    file_content = s3_service.get_document_content(current_file_path)
                    if not file_content:
                        st.error(f"No content found for file: {current_file_path}")
                        continue
                    
                    if file_type == "json":
                        json_data = json.loads(file_content.decode('utf-8'))
                        st.json(json_data)
                    
                    # Handle PDF files
                    elif file_type == "pdf":
                        base64_pdf = base64.b64encode(file_content).decode('utf-8')
                        pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="100%" height="800"></iframe>'
                        st.markdown(pdf_display, unsafe_allow_html=True)

                    # Handle Excel files
                    else:
                        excel_file = io.BytesIO(file_content)
                        if 'sheets' in file_config:
                            sheet_tabs = st.tabs([
                                f"Sheet {sheet_config['sheet_name']} - {sheet_config['description']}" 
                                for sheet_config in file_config['sheets']
                            ])
                            
                            for sheet_tab, sheet_config in zip(sheet_tabs, file_config['sheets']):
                                with sheet_tab:
                                    try:
                                        sheet_data = pd.read_excel(excel_file, sheet_name=sheet_config['sheet_name'])
                                        cleaned_sheet_data = sheet_data.dropna(how="all")
                                        cleaned_sheet_data = cleaned_sheet_data.dropna(how="all", axis=1)
                                        st.markdown(f"### {sheet_config['description']}")
                                        st.dataframe(cleaned_sheet_data)
                                    except Exception as e:
                                        st.error(f"Error loading sheet {sheet_config['sheet_name']}: {str(e)}")
                        else:
                            try:
                                sheet_data = pd.read_excel(excel_file, sheet_name=file_config['sheet_name'])
                                cleaned_sheet_data = sheet_data.dropna(how="all")
                                cleaned_sheet_data = cleaned_sheet_data.dropna(how="all", axis=1)
                                st.dataframe(cleaned_sheet_data)
                            except Exception as e:
                                st.error(f"Error loading Excel file: {str(e)}")
                                
                except Exception as e:
                    st.error(f"Error processing file: {str(e)}")
                    continue

    def _get_cached_response(self, bank_name: str, tab_name: str, year: str, period: str) -> Optional[Dict]:
        """Check if cached response exists in S3."""
        try:
            s3_service = S3Service(self.common_config['s3_config'])
            
            # Construct cache file path
            bank_folder = bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            bank_tab_name = tab_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            cache_file = f"{bank_tab_name}_{year}_{period}_response.json"
            cache_path = f"s3://{self.common_config['s3_config']['bucket']}/{self.common_config['s3_config']['main_folder']}/working_summary/{cache_file}"
            print(f"cache path:{cache_path}")
            try:
                # Try to get cached response
                content = s3_service.get_document_content(cache_path)
                if content:
                    return json.loads(content.decode('utf-8'))
            except:
                return None
                
            return None
            
        except Exception as e:
            st.error(f"Error checking cache: {str(e)}")
            return None
    
    def _save_response_to_cache(self, response: Dict, bank_name: str, tab_name: str, year: str, period: str) -> bool:
        """Save model response to S3 cache."""
        try:
            s3_client = boto3.client('s3')
            
            # Construct cache file path
            bank_folder = bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            bank_tab_name = tab_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            cache_file = f"{bank_tab_name}_{year}_{period}_response.json"
            cache_key = f"{self.common_config['s3_config']['main_folder']}/working_summary/{cache_file}"
            
            # Convert response to JSON and save
            response_json = json.dumps(response)
            s3_client.put_object(
                Bucket=self.common_config['s3_config']['bucket'],
                Key=cache_key,
                Body=response_json
            )
            
            return True
            
        except Exception as e:
            st.error(f"Error saving to cache: {str(e)}")
            return False
    
    def _render_summary_tab(self, data: pd.DataFrame, bank_config: Dict, formatted_data_dict: Dict = None):
        """Render summary tab content."""
        bank_id = bank_config['bank_info']['name'].lower().replace(' ', '_')
        tab_name = bank_config['bank_info']['tab_name'].lower().replace(' ', '_')
        
        # Initialize session state variables
        if f"data_processed_{tab_name}" not in st.session_state:
            st.session_state[f"data_processed_{tab_name}"] = False
        if f"datasets_{tab_name}" not in st.session_state:
            st.session_state[f"datasets_{tab_name}"] = None
        if f"json_response_{tab_name}" not in st.session_state:
            st.session_state[f"json_response_{tab_name}"] = None

        # Check for cached response first
        cached_response = self._get_cached_response(
            bank_config['bank_info']['name'],
            bank_config['bank_info']['tab_name'],
            st.session_state.driver_year,
            st.session_state.driver_period
        )

        col1, col2 = st.columns([4, 1])
        
        with col1:
            if cached_response:
                st.info("Using cached response. Click 'Reprocess Data' to refresh.")
                
                # Process cached response
                dataset_configs = bank_config.get('datasets', {})
                datasets = self.parse_datasets(cached_response, dataset_configs)
                
                # Update session state
                st.session_state[f"datasets_{tab_name}"] = datasets
                st.session_state[f"json_response_{tab_name}"] = cached_response
                st.session_state[f"data_processed_{tab_name}"] = True
        
        with col2:
            # Show different buttons based on cache status
            button_label = "Reprocess Data" if cached_response else "Process Data"
            if st.button(button_label, key=f"process_data_{tab_name}", use_container_width=True):
                with st.spinner("Processing financial data..."):
                    json_response = self.process_data(data, bank_config)

                    if not json_response or "data" not in json_response:
                        st.error("Failed to process data or no response received.")
                        return

                    dataset_configs = bank_config.get('datasets', {})
                    if not dataset_configs:
                        st.error("Dataset configuration is missing in bank config.")
                        return

                    # Save response to cache
                    self._save_response_to_cache(
                        json_response,
                        bank_config['bank_info']['name'],
                        bank_config['bank_info']['tab_name'],
                        st.session_state.driver_year,
                        st.session_state.driver_period
                    )

                    datasets = self.parse_datasets(json_response, dataset_configs)
                    
                    # Update session state
                    st.session_state[f"datasets_{tab_name}"] = datasets
                    st.session_state[f"json_response_{tab_name}"] = json_response
                    st.session_state[f"data_processed_{tab_name}"] = True

                    st.rerun()

        # Display results
        if st.session_state[f"data_processed_{tab_name}"]:
            if st.session_state[f"datasets_{tab_name}"]:
                self.display_datasets(st.session_state[f"datasets_{tab_name}"], bank_config)
                st.success(f"✅ Data processed successfully for {bank_config['bank_info']['name']}!")

    def _extract_data_between_markers(self, df: pd.DataFrame, start_marker: str, end_marker: str) -> pd.DataFrame:
        """
        Extract data between start and end markers, including the start marker row but excluding the end marker row.
        
        Args:
            df: Input DataFrame
            start_marker: Start marker text
            end_marker: End marker text
        
        Returns:
            DataFrame containing data between markers
        """
        try:
            # Normalize markers
            start_marker = unicodedata.normalize("NFKD", start_marker)
            end_marker = unicodedata.normalize("NFKD", end_marker)
    
            start_idx = None
            end_idx = None
            
            # Convert DataFrame to string representation for easier searching
            for idx, row in df.iterrows():
                row_values = [str(val) for val in row.values]
                row_text = ' '.join(row_values)
                
                # Normalize row text
                row_text = unicodedata.normalize("NFKD", row_text)
                
                if start_marker in row_text and start_idx is None:
                    start_idx = idx
                    print(f"Found start marker at index {start_idx}")
                elif end_marker in row_text and start_idx is not None:
                    end_idx = idx
                    print(f"Found end marker at index {end_idx}")
                    break
            
            if start_idx is not None and end_idx is not None:
                # Extract data from start_idx up to (but not including) end_idx
                extracted_data = df.iloc[start_idx:end_idx].copy()
                print(f"Extracted {len(extracted_data)} rows between markers")
                extracted_data = extracted_data.dropna(how="all")
                extracted_data = extracted_data.dropna(how="all", axis=1)
                return extracted_data
            else:
                if start_idx is None:
                    print(f"Start marker '{start_marker}' not found")
                if end_idx is None:
                    print(f"End marker '{end_marker}' not found")
                df = df.dropna(how="all")
                df = df.dropna(how="all", axis=1)
                return df
            
        except Exception as e:
            print(f"Error in data extraction: {str(e)}")
            return df
    
    def process_data(self, data: pd.DataFrame, bank_config: Dict) -> Optional[Dict]:
        """Process the data using Bedrock service."""
        try:
            data_dict = {}
            
            # Get file configuration
            file_configs = bank_config['file_config']['files']
            if not file_configs:
                raise ValueError("No file configuration found")
            
            
                
            # Process each file configuration
            for file_config in file_configs:
                file_type = file_config.get('file_type')
                s3_uri = file_config.get('s3_uri')
            
                file_pattern = file_config.get('file_pattern')
                if not file_pattern:
                    st.error("File pattern not found in configuration")
                    continue
                
                if s3_uri:
                    full_s3_path = s3_uri
                else:
                    # Construct complete S3 URI with filename
                    full_s3_path = self._construct_s3_uri(
                        bank_config['bank_info']['name'],
                        file_pattern=file_pattern,
                        file_config=file_config
                    )
                
                if not full_s3_path:
                    st.error("Failed to construct S3 URI")
                    continue
                
                # Initialize S3 service and get content
                s3_service = S3Service(self.common_config['s3_config'])
                file_content = s3_service.get_document_content(full_s3_path)
                
                # Process based on file type
                if file_type == "json":
                    json_data = json.loads(file_content.decode('utf-8'))
                    data_key = file_config.get('data_key')
                    data_dict[data_key] = json_data
                if file_config.get('file_type') == 'pdf':
                    # Process PDF sections
                    pdf_processor = PDFProcessor(file_content)
                    pdf_data = pdf_processor.process_sections(file_config.get('sections', []))
                    data_dict.update(pdf_data)
                else:
                    # Process Excel files
                    excel_file = io.BytesIO(file_content)
                    
                    # Load data from all specified sheets with their corresponding data keys
                    if 'sheets' in file_config:
                        for sheet_config in file_config['sheets']:
                            sheet_name = sheet_config['sheet_name']
                            data_key = sheet_config['data_key']
                            start_marker = sheet_config.get('start_marker')
                            end_marker = sheet_config.get('end_marker')
                            
                            try:
                                sheet_data = pd.read_excel(excel_file, sheet_name=sheet_name)
                                cleaned_data = sheet_data.dropna(how="all")
                                cleaned_data = cleaned_data.dropna(how="all", axis=1)
                                
                                # If markers are specified, extract the relevant section
                                if start_marker and end_marker:
                                    # Extract data between markers using the helper method
                                    cleaned_data = self._extract_data_between_markers(
                                        sheet_data,
                                        start_marker,
                                        end_marker
                                    )
                                    print(f"Processed data for {data_key} using markers")
                                
                                data_dict[data_key] = cleaned_data.to_string(index=False)
                            except Exception as e:
                                st.error(f"Error reading sheet {sheet_name}: {str(e)}")
                                return None
            
            # Load and prepare the prompt
            prompt_file_path = bank_config['bank_info'].get('prompt_file')
            if not prompt_file_path:
                raise ValueError("Prompt file path is not configured.")

            absolute_prompt_path = os.path.join(os.getcwd(), prompt_file_path)
            if not os.path.exists(absolute_prompt_path):
                raise FileNotFoundError(f"Prompt file not found: {absolute_prompt_path}")

            # Load and format the prompt
            prompt_with_drivers = self.load_prompt(absolute_prompt_path)
            if not prompt_with_drivers:
                raise ValueError("Failed to load prompt template with drivers")
                
            # Format with data
            prompt = prompt_with_drivers.format(**data_dict)
            if not prompt:
                raise ValueError("Failed to load prompt template with data")

            # Show the final prompt in an expander
            with st.expander("View Generated Prompt"):
                st.code(prompt, language="text")

            # Implement retry with exponential backoff
            max_retries = 5
            base_delay = 10  # Start with 10 seconds
            
            for attempt in range(max_retries):
                try:
                    response = self.bedrock_service.invoke_model_summary_analysis(prompt)
                    
                    if response and 'data' in response:
                        return response
                        
                    if not response:
                        st.warning("No response received from the model, retrying...")
                    elif 'data' not in response:
                        st.warning("Response does not contain expected 'data' field, retrying...")
                        
                except Exception as e:
                    if "ThrottlingException" in str(e):
                        if attempt < max_retries - 1:  # Don't sleep on last attempt
                            delay = base_delay * (2 ** attempt)  # Exponential backoff
                            st.warning(f"Request throttled. Retrying in {delay} seconds... (Attempt {attempt + 1}/{max_retries})")
                            time.sleep(delay)
                        continue
                    else:
                        raise e  # Re-raise if it's not a throttling error
            
            st.error("Maximum retries reached. Please try again later.")
            return None

        except Exception as e:
            st.error(f"Error processing data: {str(e)}")
            return None

    def _get_bank_id(self, bank_name: str) -> str:
        """Convert bank name to bank ID format."""
        return bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')

    def get_selected_bank(self) -> Optional[str]:
        """Get the currently selected bank."""
        if 'selected_bank' not in st.session_state:
            working_summary_tabs = self.common_config['tabs_config']['working_summary_tabs']
            for bank_name in working_summary_tabs:
                bank_id = self._get_bank_id(bank_name)
                if self.bank_configs[bank_id]['bank_info'].get('implementation_status') == 'active':
                    st.session_state.selected_bank = bank_id
                    break
        return st.session_state.get('selected_bank')
    
    def load_prompt(self, prompt_file_path: str) -> str:
        """Load the prompt content from the specified file."""
        if not os.path.exists(prompt_file_path):
            raise FileNotFoundError(f"Prompt file not found: {prompt_file_path}")
            
        try:
            with open(prompt_file_path, 'r', encoding='utf-8') as file:
                prompt_template = file.read()
                
                # Create placeholder mapping from driver values
                driver_placeholders = {
                    'current_half_year': self.driver_values.get('Half Year Period', ''),
                    'prior_half_year': self.driver_values.get('Prior Half Year Period', ''),
                    'prior_year_end': self.driver_values.get('Prior Year End Period', ''),
                    'current_quarter': self.driver_values.get('Current Quarter End Period', ''),
                    'prior_quarter': self.driver_values.get('Prior Quarter End Period', ''),
                    'total_days': self.driver_values.get('Total Days', ''),
                    'half_year_period_days': self.driver_values.get('Half Year Period Days', ''),
                    'q1_days': self.driver_values.get('Q1 Days', ''),
                    'q2_days': self.driver_values.get('Q2 Days', ''),
                    'q3_days': self.driver_values.get('Q3 Days', ''),
                    'q4_days': self.driver_values.get('Q4 Days', ''),
                    'prev_year_total_days': self.driver_values.get('Previous Year Total Days', ''),                    
                    'prev_year_half_year_period_days': self.driver_values.get('Previous Year Half Year Period Days', ''),
                    'q1_days_prev_year': self.driver_values.get('Q1 Days of previous year', ''),
                    'q2_days_prev_year': self.driver_values.get('Q2 Days of previous year', ''),
                    'q3_days_prev_year': self.driver_values.get('Q3 Days of previous year', ''),
                    'q4_days_prev_year': self.driver_values.get('Q4 Days of previous year', ''),
                    'prior_1_quarter': self.driver_values.get('Prior 1 Quarter', ''),
                    'prior_2_quarter': self.driver_values.get('Prior 2 Quarter', ''),
                    'prior_3_quarter': self.driver_values.get('Prior 3 Quarter', ''),
                    'prior_4_quarter': self.driver_values.get('Prior 4 Quarter', ''),
                    'prior_5_quarter': self.driver_values.get('Prior 5 Quarter', ''),
                    'prior_6_quarter': self.driver_values.get('Prior 6 Quarter', ''),
                    # Add formatted_data placeholder to prevent KeyError
                    'formatted_data': '{formatted_data}',
                    'formatted_data1': '{formatted_data1}',
                    'formatted_data2': '{formatted_data2}',
                    'formatted_data3': '{formatted_data3}',
                    'formatted_data4': '{formatted_data4}'
                }
                
                # Format the template with driver values while preserving formatted_data placeholder
                prompt_with_drivers = prompt_template.format(**driver_placeholders)
                
                return prompt_with_drivers
                
        except Exception as e:
            st.error(f"Error formatting prompt with driver values: {str(e)}")
            return None

    def parse_datasets(self, json_response: Dict, dataset_configs: Dict) -> Dict[str, pd.DataFrame]:
        """Parse datasets based on configuration."""
        datasets = {}
        current_dataset = None
        headers = None
        records = []

        for row in json_response.get("data", []):
            dataset_names = [config["name"] for config in dataset_configs.values()]
            if len(row) > 0 and row[0] in dataset_names:
                if current_dataset and headers and records:
                    datasets[current_dataset] = pd.DataFrame(records, columns=headers)
                current_dataset = row[0]
                headers = row
                records = []
            elif len(row) == 1 and row[0] == "":  # Handle empty rows
                if current_dataset and headers and records:
                    datasets[current_dataset] = pd.DataFrame(records, columns=headers)
                    current_dataset = None
                    headers = None
                    records = []
            elif len(row) > 1:
                records.append(row)

        if current_dataset and headers and records:
            datasets[current_dataset] = pd.DataFrame(records, columns=headers)

        return datasets
    
    def display_dataframe(self, name, df):
        # Custom CSS with explicit text colors for dark mode compatibility
        st.markdown("""
            <style>
            /* Header styling */
            .stMarkdown table thead tr th {
                background-color: #1c4e80 !important;
                color: white !important;
                font-weight: 700 !important;
                padding: 15px !important;
                border: 1px solid white !important;
                text-align: center !important;
            }
            
            /* First column styling - with fixed width */
            .stMarkdown table thead tr th:first-child,
            .stMarkdown table tbody tr td:first-child {
                background-color: #1c4e80 !important;
                color: white !important;
                font-weight: 700 !important;
                text-align: center !important;
                width: 300px !important;
                max-width: 300px !important;
                min-width: 200px !important;
                white-space: normal !important;
                word-wrap: break-word !important;
            }
            
            /* Other cells styling */
            .stMarkdown table tbody tr td {
                background-color: #e6f3ff !important;
                color: #333333 !important;
                padding: 15px !important;
                border: 1px solid white !important;
                text-align: center !important;
            }
            
            /* Table styling */
            .stMarkdown table {
                border-collapse: collapse !important;
                table-layout: fixed !important;
                width: 100% !important;
                color: #333333 !important;
            }

            /* Ensure all other columns distribute remaining space evenly */
            .stMarkdown table th:not(:first-child),
            .stMarkdown table td:not(:first-child) {
                width: auto !important;
            }

            /* Section header styling */
            .section-header {
                background-color: #006400;
                color: white;
                padding: 10px;
                margin: 20px 0 10px 0;
                font-weight: bold;
                border-radius: 5px;
            }

            /* Ensure text remains visible in dark mode */
            [data-testid="stMarkdown"] table {
                color: #333333 !important;
            }

            [data-testid="stMarkdown"] table tbody tr td {
                color: #333333 !important;
            }
            </style>
        """, unsafe_allow_html=True)
        
        st.markdown(f'<div class="section-header">{name}</div>', unsafe_allow_html=True)
        st.markdown(df.to_markdown(index=False), unsafe_allow_html=True)

    def display_datasets(self, datasets: Dict[str, pd.DataFrame], bank_config: Dict):
        """Display datasets according to configuration."""
        # Get bank ID for session state
        bank_id = bank_config['bank_info']['name'].lower().replace(' ', '_')
        tab_name = bank_config['bank_info']['tab_name'].lower().replace(' ', '_')
        
        if not datasets:
            st.warning("No datasets available to display.")
            return

        for name, df in datasets.items():
            if df.empty:
                st.warning(f"{name} is empty and will not be displayed.")
                continue

            #st.markdown(f'<div class="section-header">{name}</div>', unsafe_allow_html=True)
            #st.dataframe(df, hide_index=True, use_container_width=True)
            #st.markdown(df.to_markdown(index=False), unsafe_allow_html=True)
            self.display_dataframe(name, df)

        # Check for bank-specific json response in session state
        if f"json_response_{tab_name}" in st.session_state:
            self.create_download_file(datasets, bank_config)

    def create_download_file(self, datasets: Dict[str, pd.DataFrame], bank_config: Dict):
        """Create a downloadable file with headers included."""
        try:
            combined_data = []

            for dataset_name, df in datasets.items():
                if not df.empty:
                    # Add the dataset name as a header
                    combined_data.append([dataset_name])  # Dataset title as a row
                    combined_data.append(list(df.columns))  # Add column headers
                    combined_data.extend(df.values.tolist())  # Add data rows
                    combined_data.append([])  # Blank row for separation

            # Convert combined data to a DataFrame for CSV export
            combined_df = pd.DataFrame(combined_data)

            # Generate a timestamped filename
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            file_name = f"{bank_config['file_config']['output_prefix']}_{timestamp}.csv"

            st.markdown("")
            # Create a download button
            st.download_button(
                label=f"Download {file_name}",
                data=combined_df.to_csv(index=False, header=False).encode("utf-8"),
                file_name=file_name,
                mime="text/csv"
            )
        except Exception as e:
            st.error(f"Error creating the download file: {str(e)}")

    def _render_final_summary(self):
        """Render Final Summary section."""
        # Get tabs from config
        final_summary_tabs = self.common_config['tabs_config']['final_summary_tabs']
        tabs = st.tabs(final_summary_tabs)
        
        for tab in tabs:
            with tab:
                st.info("Implementation pending for this section.")