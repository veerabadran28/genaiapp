import streamlit as st
import pandas as pd
import os
import time
from typing import Dict, Optional
import json
import boto3
import io
import base64
import unicodedata
from src.utils.FinancialChatBot import FinancialChatBot
from src.services.s3_service import S3Service
from src.utils.pdf_processor import PDFProcessor
from src.ui.data_insights import DataInsightsUI

class SummaryAnalysisUI:
    def __init__(self, common_config: Dict, bank_configs: Dict, tab_configs: Dict, bedrock_service):
        self.common_config = common_config
        self.bank_configs = bank_configs
        self.tab_configs = tab_configs
        self.bedrock_service = bedrock_service
        self.driver_values = st.session_state.get('driver_values', {})
        
        # Initialize global tab states if not exists
        if 'tab_states' not in st.session_state:
            st.session_state.tab_states = {}

    def _initialize_tab_state(self, tab_name: str):
        """Initialize state for a specific tab if it doesn't exist."""
        if tab_name not in st.session_state.tab_states:
            st.session_state.tab_states[tab_name] = {
                "datasets": None,
                "json_response": None,
                "data_processed": False,
                "is_loading": False,
                "formatted_data": None,
                "current_year": st.session_state.driver_year,
                "current_period": st.session_state.driver_period,
                "cache_processed": False
            }

    def render(self):
        """Render the Summary Analysis interface."""
        # Apply static styling
        st.markdown("""
            <style>
            .stButton > button {
                background-color: #0051A2;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                cursor: pointer;
            }
            .section-header {
                background-color: #006A4D;
                color: white;
                padding: 10px 15px;
                margin-bottom: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            .dataframe th {
                background-color: #006A4D !important;
                color: white !important;
                text-align: center !important;
            }
            .dataframe td {
                padding: 8px !important;
            }
            .stTabs [data-baseweb="tab"] {
                background-color: #f8f9fa;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            .stTabs [data-baseweb="tab"][aria-selected="true"] {
                background-color: #0051A2 !important;
                color: white !important;
            }
            </style>
        """, unsafe_allow_html=True)

        # Render header
        col1, col2, col3 = st.columns([0.1, 10.5, 1])
        with col2:
            st.markdown("### Summary Analysis")
        with col3:
            if st.button("← Back", key="summary_back", use_container_width=True):
                st.session_state.current_view = 'main'
                st.rerun()

        # Main tabs from config
        main_tabs = st.tabs(self.common_config['tabs_config']['main_tabs'])

        with main_tabs[0]:  # Final Summary
            self._render_summary_section('final_summary')

        with main_tabs[1]:  # Working Summary
            self._render_summary_section('working_summary')
            
        with main_tabs[2]:  # Data Insights
            data_insights = DataInsightsUI(self.common_config)
            data_insights.render()
            
    def _render_summary_section(self, section_type: str):
        """Render either Final Summary or Working Summary section."""
        # Add custom CSS for radio buttons
        st.markdown("""
            <style>
            div[data-testid="stRadio"] > div {
                margin-bottom: 0px !important;
                padding-bottom: 0px !important;
            }
            div[data-testid="stHorizontalBlock"] {
                margin-bottom: 0px !important;
                padding-bottom: 0px !important;
            }
            hr {
                margin-top: 0px !important;
                margin-bottom: 1rem !important;
            }
            </style>
        """, unsafe_allow_html=True)

        # Get tabs from config
        tabs_key = f'{section_type}_tabs'
        tabs = self.common_config['tabs_config'][tabs_key]

        # Initialize active tab in session state if not exists
        active_tab_key = f'active_{section_type}_tab'
        if active_tab_key not in st.session_state:
            st.session_state[active_tab_key] = tabs[0]
            
        # Debug prints to check values
        #print(f"Current active tab: {st.session_state[active_tab_key]}")
        #print(f"Available tabs: {tabs}")
        
        try:
            current_index = tabs.index(st.session_state[active_tab_key])
        except ValueError:
            #print(f"Tab '{st.session_state[active_tab_key]}' not found in tabs list. Resetting to first tab.")
            current_index = 0
            st.session_state[active_tab_key] = tabs[0]

        # Create radio buttons for tab selection
        selected_tab = st.radio(
            "Select View",
            options=tabs,
            index=tabs.index(st.session_state[active_tab_key]),
            horizontal=True,
            key=f"{section_type}_selector_{st.session_state.get('radio_key', 0)}",  # Add dynamic key
            label_visibility="collapsed"
        )
        
        # Update session state immediately when selection changes
        if selected_tab != st.session_state[active_tab_key]:
            st.session_state[active_tab_key] = selected_tab
            # Force radio button refresh by updating its key
            st.session_state['radio_key'] = st.session_state.get('radio_key', 0) + 1
            st.rerun()

        # Add divider
        st.divider()

        # Update active tab if changed
        if selected_tab != st.session_state[active_tab_key]:
            st.session_state[active_tab_key] = selected_tab
            st.rerun()

        # Get tab/bank id and render content
        content_id = selected_tab.lower().replace(' ', '_').replace('(', '').replace(')', '')
        
        if section_type == 'working_summary':
            # Use existing bank config for working summary
            config = self.bank_configs.get(content_id)
            config_type = 'bank_info'
        else:
            # Use tab config for final summary
            config = self.tab_configs.get(content_id)
            config_type = 'tab_info'

        if config and config[config_type].get('implementation_status') == 'active':
            # For working summary, set selected bank
            if section_type == 'working_summary':
                st.session_state.selected_bank = content_id

            # Convert tab config to bank config format if needed
            if section_type == 'final_summary':
                config = self._convert_tab_to_bank_config(config)

            self._render_bank_analysis(config)
        else:
            st.info(f"Implementation pending for {selected_tab}")

    def _convert_tab_to_bank_config(self, tab_config: Dict) -> Dict:
        """Convert tab config to bank config format for compatibility."""
        return {
            'bank_info': {
                'name': tab_config['tab_info']['name'],
                'tab_name': tab_config['tab_info']['name'],
                'implementation_status': tab_config['tab_info']['implementation_status'],
                'prompt_file': tab_config['tab_info'].get('prompt_file')
            },
            'file_config': tab_config.get('file_config', {
                'files': [],
                'output_prefix': f'final_summary_{tab_config["tab_info"]["name"].lower().replace(" ", "_")}'
            }),
            'datasets': tab_config.get('datasets', {})
        }

    def _render_working_summary(self):
        """Render Working Summary section using working_summary_tabs from config."""
        # Add custom CSS to style radio buttons
        st.markdown("""
            <style>
            div[data-testid="stRadio"] > div {
                margin-bottom: 0px !important;
                padding-bottom: 0px !important;
            }
            div[data-testid="stHorizontalBlock"] {
                margin-bottom: 0px !important;
                padding-bottom: 0px !important;
            }
            hr {
                margin-top: 0px !important;
                margin-bottom: 1rem !important;
            }
            </style>
        """, unsafe_allow_html=True)

        # Get tabs from config
        working_summary_tabs = self.common_config['tabs_config']['working_summary_tabs']

        # Initialize active tab in session state if not exists
        if 'active_working_tab' not in st.session_state:
            st.session_state.active_working_tab = working_summary_tabs[0]

        # Create radio buttons for tab selection
        selected_tab = st.radio(
            "Select Bank",
            options=working_summary_tabs,
            index=working_summary_tabs.index(st.session_state.active_working_tab),
            horizontal=True,
            key="bank_selector",
            label_visibility="collapsed"
        )

        # Add divider
        st.divider()

        # Update active tab if changed
        if selected_tab != st.session_state.active_working_tab:
            st.session_state.active_working_tab = selected_tab
            st.rerun()

        # Render the selected tab's content
        bank_id = self._get_bank_id(selected_tab)
        bank_config = self.bank_configs.get(bank_id)

        if bank_config and bank_config['bank_info'].get('implementation_status') == 'active':
            st.session_state.selected_bank = bank_id
            self._render_bank_analysis(bank_config)
        else:
            st.info(f"Implementation pending for {selected_tab}")
        
    def _construct_filename(self, file_pattern: str) -> str:
        """Construct filename using driver values and pattern."""
        try:
            # Get all necessary values from driver_values
            full_year = st.session_state.get('driver_year', '')
            year_last_two_digit = full_year[-2:] if full_year else ''
            quarter_period_lower = self.driver_values.get("Quarter End Results Period", "").lower()
            quarter_period_caps = self.driver_values.get("Quarter End Results Period", "")
            quarter_period_year = self.driver_values.get("Quarter End Results Period Year", "")
            prior_quarter_period_caps = self.driver_values.get("Prior Quarter End Results Period", "")[:2]
            prior_quarter_end_year = self.driver_values.get("Prior Quarter End Results Period Year", "")
            half_year_period_lower = self.driver_values.get("Half Year End Results Period", "").lower()
            half_year_period_caps = self.driver_values.get("Half Year End Results Period", "")            

            # Set period constants
            if half_year_period_lower == "h1":
                period_const_lower = 'hy'
                period_const_caps = 'HY'
            elif half_year_period_lower == "h2":
                period_const_lower = 'fy'
                period_const_caps = 'FY'
            else:
                period_const_lower = ''
                period_const_caps = ''

            # Replace placeholders in pattern
            filename = file_pattern.format(
                full_year=full_year,
                year_last_two_digit=year_last_two_digit,
                quarter_period_lower=quarter_period_lower,
                quarter_period_caps=quarter_period_caps,
                quarter_period_year=quarter_period_year,
                prior_quarter_period_caps=prior_quarter_period_caps,
                prior_quarter_end_year=prior_quarter_end_year,
                half_year_period_lower=half_year_period_lower,
                half_year_period_caps=half_year_period_caps,
                period_const_lower=period_const_lower,
                period_const_caps=period_const_caps
            )
            #print(f"filename:{filename}")
            return filename

        except Exception as e:
            st.error(f"Error constructing filename: {str(e)}")
            return None
    
    def _construct_s3_uri(self, bank_name: str, file_pattern: str = None, file_config: Dict = None) -> str:
        """
        Construct complete S3 URI using driver values and bank name.
        
        Args:
            bank_name: Name of the bank
            file_pattern: Pattern for the filename
            file_config: Configuration for the specific file
        """
        try:
            if not self.driver_values:
                st.error("No driver values available")
                return None
                
            bucket = self.common_config['s3_config']['bucket']
            main_folder = self.common_config['s3_config']['main_folder']
            
            # Determine which period to use based on file config
            if file_config and 'period_type' in file_config:
                # Use the period type specified in config
                period_template = file_config.get('period_type')
                # Replace placeholders in period_type with actual values
                period = period_template.format(
                    quarter_period_caps=self.driver_values.get("Quarter End Results Period"),
                    prior_quarter_period_caps=self.driver_values.get("Prior Quarter End Results Period"),
                )
            else:
                # Default to Quarter End Results Period for backward compatibility
                period = self.driver_values.get("Quarter End Results Period")
            
            #print(f"period:{period}")
            if not period:
                st.error("Period not found in driver values")
                return None
                
            # Determine which year to use
            if file_config and 'period_year' in file_config:
                # Use the year specified in config
                year_template = file_config.get('period_year')
                # Replace placeholders in period_year with actual values
                year = year_template.format(
                    quarter_period_year=self.driver_values.get("Quarter End Results Period Year"),
                    prior_quarter_end_year=self.driver_values.get("Prior Quarter End Results Period Year")
                )
            else:
                # Default to session state year for backward compatibility
                year = self.driver_values.get("Quarter End Results Period Year")
                
            if not year:
                st.error("No year found")
                return None
            #print(f"year:{year}")
            
            # Clean bank name for S3 path
            bank_folder = bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            
            # Construct base S3 URI with period-specific folder
            s3_uri = f"s3://{bucket}/{main_folder}/{bank_folder}/{year}/{period}"
            
            # If file pattern is provided, construct and append filename
            if file_pattern:
                filename = self._construct_filename(file_pattern)
                if filename:
                    s3_uri = f"{s3_uri}/{filename}"
                #print(f"s3_uri:{s3_uri}")
            return s3_uri
            
        except Exception as e:
            st.error(f"Error constructing S3 URI: {str(e)}")
            return None
    
    def _process_json_file(self, s3_uri: str, sections: list) -> dict:
        """Fetch and process a JSON file from S3."""
        try:
            s3_service = S3Service(self.common_config['s3_config'])
            file_content = s3_service.get_document_content(s3_uri)

            if not file_content:
                st.error(f"No content found for S3 URI: {s3_uri}")
                return {}

            json_data = json.loads(file_content.decode('utf-8'))
            processed_data = {}

            for section in sections:
                data_key = section.get('data_key')
                if data_key and data_key in json_data:
                    processed_data[data_key] = json_data[data_key]
                else:
                    st.warning(f"Data key '{data_key}' not found in JSON data.")

            return processed_data

        except Exception as e:
            st.error(f"Error processing JSON file: {str(e)}")
            return {}
    
    def _render_bank_analysis(self, bank_config: Dict):
        """Render bank analysis section."""
        try:
            # Get bank ID and tab name
            bank_id = bank_config['bank_info']['name'].lower().replace(' ', '_')
            tab_name = bank_config['bank_info']['tab_name'].lower().replace(' ', '_')
            
            # Initialize tab state
            self._initialize_tab_state(tab_name)
            tab_state = st.session_state.tab_states[tab_name]
            
            # Check for cached response first
            cached_response = self._get_cached_response(
                bank_config['bank_info']['name'],
                bank_config['bank_info']['tab_name'],
                st.session_state.driver_year,
                st.session_state.driver_period
            )

            if cached_response and not tab_state["cache_processed"]:
                dataset_configs = bank_config.get('datasets', {})
                datasets = self.parse_datasets(cached_response, dataset_configs)
                
                tab_state.update({
                    "datasets": datasets,
                    "json_response": cached_response,
                    "data_processed": True,
                    "cache_processed": True,
                    "current_year": st.session_state.driver_year,
                    "current_period": st.session_state.driver_period
                })

            # Render layout with data
            self._render_layout(bank_config, tab_name, tab_state.get("formatted_data"))

        except Exception as e:
            st.error(f"Error in bank analysis: {str(e)}")
            st.exception(e)

    def _render_layout(self, bank_config: Dict, tab_name: str, formatted_data_dict: Dict = None):
        """Render the layout with either cached or processed data."""
        # Layout columns for main content and sidebar
        col1, col2, col3 = st.columns([0.00001, 2.5, 1])
        
        # Sidebar with optional logo and description
        with col3:
            if bank_config['bank_info'].get('logo_url') and bank_config['bank_info'].get('description'):
                st.image(bank_config['bank_info']['logo_url'], width=200)
                desc_container = st.container(border=True)
                desc_container.write(bank_config['bank_info'].get('description', ''))
            
            # Add chatbot if data is processed
            if tab_name in st.session_state.tab_states:
                tab_state = st.session_state.tab_states[tab_name]
                if tab_state["data_processed"] and tab_state["datasets"] and tab_state["json_response"]:
                    try:
                        combined_data1 = []
                        for dataset_name, df in tab_state["datasets"].items():
                            if not df.empty:
                                combined_data1.append([dataset_name])
                                combined_data1.append(list(df.columns))
                                combined_data1.extend(df.values.tolist())
                                combined_data1.append([])

                        combined_df1 = pd.DataFrame(combined_data1)
                        chatbot = FinancialChatBot(
                            datasets={'combined': combined_df1},
                            model_response={},
                            bank_info=bank_config['bank_info'],
                            bedrock_service=self.bedrock_service
                        )
                        chatbot.render_chat_interface()
                    except Exception as e:
                        st.error(f"Error initializing chatbot: {str(e)}")
        
        # Main content area
        with col2:
            tab1, tab2 = st.tabs(self.common_config['tabs_config']['main_view_tabs'])
            
            # Summary Tab
            with tab1:
                self._render_summary_tab(pd.DataFrame(), bank_config, formatted_data_dict)

            # Data Preview Tab
            with tab2:
                self._render_data_preview(bank_config['file_config']['files'], bank_config)

        # Footer
        st.markdown("<hr style='margin: 15px 0px; border: 1px solid #00b8e6'>", unsafe_allow_html=True)
        st.markdown(
            "<div style='text-align: center; color: #666666;'>Competitor Analysis | Powered by AWS Bedrock Claude 3.5 Sonnet</div>",
            unsafe_allow_html=True
        )

    def _handle_excel_data(self, excel_file: io.BytesIO, sheet_config: Dict) -> pd.DataFrame:
        """Handle Excel data reading with proper data type handling."""
        try:
            # Read Excel with all columns as string type initially
            sheet_data = pd.read_excel(
                excel_file, 
                sheet_name=sheet_config['sheet_name'],
                dtype=str  # Read all columns as strings initially
            )
            
            # Clean the data
            cleaned_data = sheet_data.dropna(how="all")
            cleaned_data = cleaned_data.dropna(how="all", axis=1)
            
            # If markers are specified, extract the relevant section
            if sheet_config.get('start_marker') and sheet_config.get('end_marker'):
                cleaned_data = self._extract_data_between_markers(
                    cleaned_data,
                    sheet_config['start_marker'],
                    sheet_config['end_marker']
                )
            
            # Convert numeric columns where possible
            for col in cleaned_data.columns:
                try:
                    # Try to convert to numeric, but keep as string if it fails
                    numeric_data = pd.to_numeric(cleaned_data[col], errors='coerce')
                    # Only convert if we don't lose any data (no NaN introduced)
                    if not numeric_data.isna().any():
                        cleaned_data[col] = numeric_data
                except:
                    continue
                    
            return cleaned_data
        except Exception as e:
            st.error(f"Error processing Excel sheet: {str(e)}")
            return pd.DataFrame()
    
    def _render_data_preview(self, file_configs, bank_config):
        """Render data preview section."""
        s3_service = S3Service(self.common_config['s3_config'])
        st.markdown("### Raw Data Preview")

        # Ensure file_configs is a list
        if not isinstance(file_configs, list):
            file_configs = [file_configs]

        # Create tabs for each file
        file_tabs = st.tabs([
            self._construct_filename(file_config.get('file_pattern', f'File {i+1}'))
            for i, file_config in enumerate(file_configs)
        ])
        
        for tab, file_config in zip(file_tabs, file_configs):
            with tab:
                try:
                    file_type = file_config.get('file_type')
                    s3_uri = file_config.get('s3_uri')

                    if s3_uri:
                        current_file_path = s3_uri
                    else:
                        current_file_path = self._construct_s3_uri(
                            bank_config['bank_info']['name'],
                            file_pattern=file_config.get('file_pattern'),
                            file_config=file_config
                        )

                    # Get file content based on type
                    file_content = s3_service.get_document_content(current_file_path)
                    if not file_content:
                        st.error(f"No content found for file: {current_file_path}")
                        continue
                    
                    if file_type == "json":
                        json_data = json.loads(file_content.decode('utf-8'))
                        st.json(json_data)
                    elif file_type == "pdf":
                        base64_pdf = base64.b64encode(file_content).decode('utf-8')
                        pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="100%" height="800"></iframe>'
                        st.markdown(pdf_display, unsafe_allow_html=True)
                    else:
                        # Handle Excel files
                        excel_file = io.BytesIO(file_content)
                        if 'sheets' in file_config:
                            sheet_tabs = st.tabs([
                                f"Sheet {sheet_config['sheet_name']} - {sheet_config['description']}" 
                                for sheet_config in file_config['sheets']
                            ])
                            
                            for sheet_tab, sheet_config in zip(sheet_tabs, file_config['sheets']):
                                with sheet_tab:
                                    try:
                                        cleaned_sheet_data = self._handle_excel_data(excel_file, sheet_config)
                                        st.markdown(f"### {sheet_config['description']}")
                                        st.dataframe(cleaned_sheet_data, use_container_width=True)
                                    except Exception as e:
                                        st.error(f"Error loading sheet {sheet_config['sheet_name']}: {str(e)}")
                        else:
                            try:
                                sheet_config = {'sheet_name': file_config['sheet_name']}
                                cleaned_sheet_data = self._handle_excel_data(excel_file, sheet_config)
                                st.dataframe(cleaned_sheet_data, use_container_width=True)
                            except Exception as e:
                                st.error(f"Error loading Excel file: {str(e)}")
                                
                except Exception as e:
                    st.error(f"Error processing file: {str(e)}")
                    continue

    def _get_cached_response(self, content_name: str, tab_name: str, year: str, period: str) -> Optional[Dict]:
        """Check if cached response exists in S3."""
        try:
            s3_service = S3Service(self.common_config['s3_config'])
            
            # Construct cache file path
            content_folder = content_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            content_tab_name = tab_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            cache_file = f"{content_tab_name}_{year}_{period}_response.json"
            cache_path = f"s3://{self.common_config['s3_config']['bucket']}/{self.common_config['s3_config']['main_folder']}/working_summary/{cache_file}"
            
            try:
                # Try to get cached response
                content = s3_service.get_document_content(cache_path)
                if content:
                    return json.loads(content.decode('utf-8'))
            except:
                return None
                
            return None
            
        except Exception as e:
            st.error(f"Error checking cache: {str(e)}")
            return None

    def _save_response_to_cache(self, response: Dict, content_name: str, tab_name: str, year: str, period: str) -> bool:
        """Save model response to S3 cache."""
        try:
            s3_client = boto3.client('s3')
            
            # Construct cache file path
            content_folder = content_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            content_tab_name = tab_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            cache_file = f"{content_tab_name}_{year}_{period}_response.json"
            cache_key = f"{self.common_config['s3_config']['main_folder']}/working_summary/{cache_file}"
            
            # Convert response to JSON and save
            response_json = json.dumps(response)
            s3_client.put_object(
                Bucket=self.common_config['s3_config']['bucket'],
                Key=cache_key,
                Body=response_json
            )
            
            return True
            
        except Exception as e:
            st.error(f"Error saving to cache: {str(e)}")
            return False
    
    def _render_summary_tab(self, data: pd.DataFrame, bank_config: Dict, formatted_data_dict: Dict = None):
        """Render summary tab content with tab isolation."""
        bank_id = bank_config['bank_info']['name'].lower().replace(' ', '_')
        tab_name = bank_config['bank_info']['tab_name'].lower().replace(' ', '_')
        
        # Get or initialize tab state
        self._initialize_tab_state(tab_name)
        tab_state = st.session_state.tab_states[tab_name]
        
        # Check for cached response
        cached_response = self._get_cached_response(
            bank_config['bank_info']['name'],
            bank_config['bank_info']['tab_name'],
            st.session_state.driver_year,
            st.session_state.driver_period
        )

        col1, col2 = st.columns([4, 1])
        
        with col1:
            if cached_response:
                st.info("Using cached response. Click 'Reprocess Data' to refresh.")
                
                if not tab_state["data_processed"]:
                    dataset_configs = bank_config.get('datasets', {})
                    datasets = self.parse_datasets(cached_response, dataset_configs)
                    
                    # Update tab state
                    tab_state.update({
                        "datasets": datasets,
                        "json_response": cached_response,
                        "data_processed": True,
                        "cache_processed": True,
                        "current_year": st.session_state.driver_year,
                        "current_period": st.session_state.driver_period
                    })
        
        with col2:
            button_label = "Reprocess Data" if cached_response else "Process Data"
            process_clicked = st.button(button_label, key=f"process_data_{tab_name}", use_container_width=True)
            
            if process_clicked:
                st.session_state[f"processing_{tab_name}"] = True
                st.rerun()
                
            if st.session_state.get(f"processing_{tab_name}", False):
                with st.spinner("Processing financial data..."):
                    json_response = self.process_data(data, bank_config, tab_name)

                    if not json_response or "data" not in json_response:
                        st.error("Failed to process data or no response received.")
                        tab_state["is_loading"] = False
                        st.session_state[f"processing_{tab_name}"] = False
                        return

                    dataset_configs = bank_config.get('datasets', {})
                    if not dataset_configs:
                        st.error("Dataset configuration is missing in config.")
                        tab_state["is_loading"] = False
                        st.session_state[f"processing_{tab_name}"] = False
                        return

                    # Save to cache
                    self._save_response_to_cache(
                        json_response,
                        bank_config['bank_info']['name'],
                        bank_config['bank_info']['tab_name'],
                        st.session_state.driver_year,
                        st.session_state.driver_period
                    )

                    datasets = self.parse_datasets(json_response, dataset_configs)
                    
                    # Update tab state
                    tab_state.update({
                        "datasets": datasets,
                        "json_response": json_response,
                        "data_processed": True,
                        "is_loading": False,
                        "formatted_data": formatted_data_dict,
                        "current_year": st.session_state.driver_year,
                        "current_period": st.session_state.driver_period
                    })
                    
                    # Clear processing state
                    st.session_state[f"processing_{tab_name}"] = False
                    
                    # Rerun this specific tab's component
                    st.rerun()

        # Display results
        if tab_state["data_processed"] and tab_state["datasets"]:
            self.display_datasets(tab_state["datasets"], bank_config, tab_name)
            st.success(f"✅ Data processed successfully for {bank_config['bank_info']['name']}!")

    def _extract_data_between_markers(self, df: pd.DataFrame, start_marker: str, end_marker: str) -> pd.DataFrame:
        """
        Extract data between start and end markers, including the start marker row but excluding the end marker row.
        
        Args:
            df: Input DataFrame
            start_marker: Start marker text
            end_marker: End marker text
        
        Returns:
            DataFrame containing data between markers
        """
        try:
            # Normalize markers
            start_marker = unicodedata.normalize("NFKD", start_marker)
            end_marker = unicodedata.normalize("NFKD", end_marker)

            start_idx = None
            end_idx = None
            
            # Convert DataFrame to string representation for easier searching
            for idx, row in df.iterrows():
                row_values = [str(val) for val in row.values]
                row_text = ' '.join(row_values)
                
                # Normalize row text
                row_text = unicodedata.normalize("NFKD", row_text)
                
                if start_marker in row_text and start_idx is None:
                    start_idx = idx
                elif end_marker in row_text and start_idx is not None:
                    end_idx = idx
                    break
            
            if start_idx is not None and end_idx is not None:
                # Extract data from start_idx up to (but not including) end_idx
                extracted_data = df.iloc[start_idx:end_idx].copy()
                extracted_data = extracted_data.dropna(how="all")
                extracted_data = extracted_data.dropna(how="all", axis=1)
                return extracted_data
            else:
                df = df.dropna(how="all")
                df = df.dropna(how="all", axis=1)
                return df
            
        except Exception as e:
            print(f"Error in data extraction: {str(e)}")
            return df
    
    def process_data(self, data: pd.DataFrame, bank_config: Dict, tab_name: str) -> Optional[Dict]:
        """Process the data using Bedrock service with tab-specific state management."""
        try:
            # Get or initialize tab state
            if tab_name not in st.session_state.tab_states:
                st.session_state.tab_states[tab_name] = {
                    "datasets": None,
                    "json_response": None,
                    "data_processed": False,
                    "is_loading": False,
                    "formatted_data": None,
                    "current_year": st.session_state.driver_year,
                    "current_period": st.session_state.driver_period
                }
            
            tab_state = st.session_state.tab_states[tab_name]
            data_dict = {}
                
            # Get file configuration
            file_configs = bank_config['file_config']['files']
            if not file_configs:
                raise ValueError("No file configuration found")
                
            # Process each file configuration
            for file_config in file_configs:
                file_type = file_config.get('file_type')
                s3_uri = file_config.get('s3_uri')
            
                file_pattern = file_config.get('file_pattern')
                if not file_pattern:
                    st.error("File pattern not found in configuration")
                    continue
                
                if s3_uri:
                    full_s3_path = s3_uri
                else:
                    # Construct complete S3 URI with filename
                    full_s3_path = self._construct_s3_uri(
                        bank_config['bank_info']['name'],
                        file_pattern=file_pattern,
                        file_config=file_config
                    )

                if not full_s3_path:
                    st.error("Failed to construct S3 URI")
                    continue
                
                # Initialize S3 service and get content
                s3_service = S3Service(self.common_config['s3_config'])
                file_content = s3_service.get_document_content(full_s3_path)
                
                if not file_content:
                    st.error(f"No content found for file: {full_s3_path}")
                    continue
                
                # Process based on file type
                if file_type == "json":
                    json_data = json.loads(file_content.decode('utf-8'))
                    data_key = file_config.get('data_key')
                    data_dict[data_key] = json_data
                elif file_type == 'pdf':
                    # Process PDF sections
                    pdf_processor = PDFProcessor(file_content)
                    pdf_data = pdf_processor.process_sections(file_config.get('sections', []))
                    data_dict.update(pdf_data)
                else:
                    # Process Excel files
                    excel_file = io.BytesIO(file_content)
                    
                    # Load data from all specified sheets with their corresponding data keys
                    if 'sheets' in file_config:
                        for sheet_config in file_config['sheets']:
                            sheet_name = sheet_config['sheet_name']
                            data_key = sheet_config['data_key']
                            start_marker = sheet_config.get('start_marker')
                            end_marker = sheet_config.get('end_marker')
                            
                            try:
                                sheet_data = pd.read_excel(excel_file, sheet_name=sheet_name)
                                cleaned_data = sheet_data.dropna(how="all")
                                cleaned_data = cleaned_data.dropna(how="all", axis=1)
                                
                                # If markers are specified, extract the relevant section
                                if start_marker and end_marker:
                                    cleaned_data = self._extract_data_between_markers(
                                        sheet_data,
                                        start_marker,
                                        end_marker
                                    )
                                
                                data_dict[data_key] = cleaned_data.to_string(index=False)
                            except Exception as e:
                                st.error(f"Error reading sheet {sheet_name}: {str(e)}")
                                return None
            
            # Load and prepare the prompt
            prompt_file_path = bank_config['bank_info'].get('prompt_file')
            if not prompt_file_path:
                raise ValueError("Prompt file path is not configured.")

            absolute_prompt_path = os.path.join(os.getcwd(), prompt_file_path)
            if not os.path.exists(absolute_prompt_path):
                raise FileNotFoundError(f"Prompt file not found: {absolute_prompt_path}")

            # Load and format the prompt
            prompt_with_drivers = self.load_prompt(absolute_prompt_path)
            if not prompt_with_drivers:
                raise ValueError("Failed to load prompt template with drivers")
                
            # Format with data
            prompt = prompt_with_drivers.format(**data_dict)
            if not prompt:
                raise ValueError("Failed to load prompt template with data")

            # Show the final prompt in an expander
            with st.expander("View Generated Prompt"):
                st.code(prompt, language="text")

            # Implement retry with exponential backoff
            max_retries = 5
            base_delay = 10  # Start with 10 seconds
            
            for attempt in range(max_retries):
                try:
                    response = self.bedrock_service.invoke_model_summary_analysis(prompt)
                    
                    if response and 'data' in response:
                        # Update tab state with processed data
                        tab_state.update({
                            "formatted_data": data_dict,
                            "current_year": st.session_state.driver_year,
                            "current_period": st.session_state.driver_period,
                            "is_loading": False,
                            "data_processed": True
                        })
                        return response
                        
                    if not response:
                        st.warning("No response received from the model, retrying...")
                    elif 'data' not in response:
                        st.warning("Response does not contain expected 'data' field, retrying...")
                        
                except Exception as e:
                    if "ThrottlingException" in str(e):
                        if attempt < max_retries - 1:  # Don't sleep on last attempt
                            delay = base_delay * (2 ** attempt)  # Exponential backoff
                            st.warning(f"Request throttled. Retrying in {delay} seconds... (Attempt {attempt + 1}/{max_retries})")
                            time.sleep(delay)
                        continue
                    else:
                        raise e  # Re-raise if it's not a throttling error
            
            st.error("Maximum retries reached. Please try again later.")
            tab_state["is_loading"] = False
            return None

        except Exception as e:
            tab_state["is_loading"] = False
            st.error(f"Error processing data: {str(e)}")
            return None

    def _get_bank_id(self, bank_name: str) -> str:
        """Convert bank name to bank ID format."""
        return bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
    
    def load_prompt(self, prompt_file_path: str) -> str:
        """Load the prompt content from the specified file."""
        if not os.path.exists(prompt_file_path):
            raise FileNotFoundError(f"Prompt file not found: {prompt_file_path}")
            
        try:
            with open(prompt_file_path, 'r', encoding='utf-8') as file:
                prompt_template = file.read()
                
                # Create placeholder mapping from driver values
                driver_placeholders = {
                    'current_half_year': self.driver_values.get('Half Year Period', ''),
                    'prior_half_year': self.driver_values.get('Prior Half Year Period', ''),
                    'prior_year_end': self.driver_values.get('Prior Year End Period', ''),
                    'current_quarter': self.driver_values.get('Current Quarter End Period', ''),
                    'prior_quarter': self.driver_values.get('Prior Quarter End Period', ''),
                    'total_days': self.driver_values.get('Total Days', ''),
                    'half_year_period_days': self.driver_values.get('Half Year Period Days', ''),
                    'q1_days': self.driver_values.get('Q1 Days', ''),
                    'q2_days': self.driver_values.get('Q2 Days', ''),
                    'q3_days': self.driver_values.get('Q3 Days', ''),
                    'q4_days': self.driver_values.get('Q4 Days', ''),
                    'prev_year_total_days': self.driver_values.get('Previous Year Total Days', ''),                    
                    'prev_year_half_year_period_days': self.driver_values.get('Previous Year Half Year Period Days', ''),
                    'q1_days_prev_year': self.driver_values.get('Q1 Days of previous year', ''),
                    'q2_days_prev_year': self.driver_values.get('Q2 Days of previous year', ''),
                    'q3_days_prev_year': self.driver_values.get('Q3 Days of previous year', ''),
                    'q4_days_prev_year': self.driver_values.get('Q4 Days of previous year', ''),
                    'prior_1_quarter': self.driver_values.get('Prior 1 Quarter', ''),
                    'prior_2_quarter': self.driver_values.get('Prior 2 Quarter', ''),
                    'prior_3_quarter': self.driver_values.get('Prior 3 Quarter', ''),
                    'prior_4_quarter': self.driver_values.get('Prior 4 Quarter', ''),
                    'prior_5_quarter': self.driver_values.get('Prior 5 Quarter', ''),
                    'prior_6_quarter': self.driver_values.get('Prior 6 Quarter', ''),
                    # Add formatted_data placeholder to prevent KeyError
                    'formatted_data': '{formatted_data}',
                    'formatted_data1': '{formatted_data1}',
                    'formatted_data2': '{formatted_data2}',
                    'formatted_data3': '{formatted_data3}',
                    'formatted_data4': '{formatted_data4}',
                    'formatted_data5': '{formatted_data5}'
                }
                
                # Format the template with driver values while preserving formatted_data placeholder
                prompt_with_drivers = prompt_template.format(**driver_placeholders)
                
                return prompt_with_drivers
                
        except Exception as e:
            st.error(f"Error formatting prompt with driver values: {str(e)}")
            return None

    def parse_datasets(self, json_response: Dict, dataset_configs: Dict) -> Dict[str, pd.DataFrame]:
        """Parse datasets based on configuration."""
        datasets = {}
        current_dataset = None
        headers = None
        records = []

        for row in json_response.get("data", []):
            dataset_names = [config["name"] for config in dataset_configs.values()]
            if len(row) > 0 and row[0] in dataset_names:
                if current_dataset and headers and records:
                    datasets[current_dataset] = pd.DataFrame(records, columns=headers)
                current_dataset = row[0]
                headers = row
                records = []
            elif len(row) == 1 and row[0] == "":  # Handle empty rows
                if current_dataset and headers and records:
                    datasets[current_dataset] = pd.DataFrame(records, columns=headers)
                    current_dataset = None
                    headers = None
                    records = []
            elif len(row) > 1:
                records.append(row)

        if current_dataset and headers and records:
            datasets[current_dataset] = pd.DataFrame(records, columns=headers)

        return datasets
    
    def display_dataframe(self, name: str, df: pd.DataFrame):
        """Display a formatted dataframe."""
        # Custom CSS with explicit text colors for dark mode compatibility
        st.markdown("""
            <style>
            /* Header styling */
            .stMarkdown table thead tr th {
                background-color: #1c4e80 !important;
                color: white !important;
                font-weight: 700 !important;
                padding: 15px !important;
                border: 1px solid white !important;
                text-align: center !important;
            }
            
            /* First column styling - with fixed width */
            .stMarkdown table thead tr th:first-child,
            .stMarkdown table tbody tr td:first-child {
                background-color: #1c4e80 !important;
                color: white !important;
                font-weight: 700 !important;
                text-align: center !important;
                width: 300px !important;
                max-width: 300px !important;
                min-width: 200px !important;
                white-space: normal !important;
                word-wrap: break-word !important;
            }
            
            /* Other cells styling */
            .stMarkdown table tbody tr td {
                background-color: #e6f3ff !important;
                color: #333333 !important;
                padding: 15px !important;
                border: 1px solid white !important;
                text-align: center !important;
            }
            
            /* Table styling */
            .stMarkdown table {
                border-collapse: collapse !important;
                table-layout: fixed !important;
                width: 100% !important;
                color: #333333 !important;
            }

            /* Ensure all other columns distribute remaining space evenly */
            .stMarkdown table th:not(:first-child),
            .stMarkdown table td:not(:first-child) {
                width: auto !important;
            }

            /* Section header styling */
            .section-header {
                background-color: #006400;
                color: white;
                padding: 10px;
                margin: 20px 0 10px 0;
                font-weight: bold;
                border-radius: 5px;
            }

            /* Ensure text remains visible in dark mode */
            [data-testid="stMarkdown"] table {
                color: #333333 !important;
            }

            [data-testid="stMarkdown"] table tbody tr td {
                color: #333333 !important;
            }
            </style>
        """, unsafe_allow_html=True)
        
        st.markdown(f'<div class="section-header">{name}</div>', unsafe_allow_html=True)
        st.markdown(df.to_markdown(index=False), unsafe_allow_html=True)

    def display_datasets(self, datasets: Dict[str, pd.DataFrame], config: Dict, tab_name: str):
        """Display datasets with tab isolation."""
        if not datasets:
            st.warning("No datasets available to display.")
            return

        for name, df in datasets.items():
            if df.empty:
                st.warning(f"{name} is empty and will not be displayed.")
                continue
            self.display_dataframe(name, df)

        # Create download with tab-specific state
        if tab_name in st.session_state.tab_states and st.session_state.tab_states[tab_name]["json_response"]:
            self.create_download_file(datasets, config, tab_name)

    def create_download_file(self, datasets: Dict[str, pd.DataFrame], config: Dict, tab_name: str):
        """Create download file with tab-specific key."""
        try:
            combined_data = []
            for dataset_name, df in datasets.items():
                if not df.empty:
                    combined_data.append([dataset_name])
                    combined_data.append(list(df.columns))
                    combined_data.extend(df.values.tolist())
                    combined_data.append([])

            combined_df = pd.DataFrame(combined_data)
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            file_name = f"{config['file_config']['output_prefix']}_{timestamp}.csv"

            st.markdown("")
            st.download_button(
                label=f"Download {file_name}",
                data=combined_df.to_csv(index=False, header=False).encode("utf-8"),
                file_name=file_name,
                mime="text/csv",
                key=f"download_{tab_name}"  # Add tab-specific key
            )
        except Exception as e:
            st.error(f"Error creating the download file: {str(e)}")

    def _render_final_summary(self):
        """Render Final Summary section."""
        # Get tabs from config
        final_summary_tabs = self.common_config['tabs_config']['final_summary_tabs']
        tabs = st.tabs(final_summary_tabs)
        
        for tab in tabs:
            with tab:
                st.info("Implementation pending for this section.")