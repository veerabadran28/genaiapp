import io
import tempfile
import os
import logging
from typing import Dict, List, Optional, BinaryIO, Any
import pandas as pd
import PyPDF2
import boto3
import json
from botocore.exceptions import ClientError
from datetime import datetime
import time
import requests
from langchain.text_splitter import RecursiveCharacterTextSplitter

class DocumentProcessor:
    def __init__(self, config: Dict):
        """Initialize document processor with configuration."""
        self.config = config
        self.logger = self._setup_logger()
        
        # Initialize AWS clients
        self.s3 = boto3.client('s3')
        self.textract = boto3.client('textract')
        self.transcribe = boto3.client('transcribe')
        self.comprehend = boto3.client('comprehend')
        self.bedrock = boto3.client('bedrock-runtime')
        self.kendra = boto3.client('kendra')

    def _setup_logger(self) -> logging.Logger:
        """Set up logger for the document processor."""
        logger = logging.getLogger('DocumentProcessor')
        logger.setLevel(logging.INFO)
        
        # Create console handler with formatting
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger

    def process_document(self, file: BinaryIO, filename: str) -> List[Dict]:
        """Main method to process any document type."""
        try:
            # Get file extension and validate
            file_extension = os.path.splitext(filename)[1].lower()
            
            # Create temp file if needed
            temp_file = None
            file_content = None
            
            try:
                # Read file content
                file.seek(0)
                file_content = file.read()
                
                # Process based on file type
                if file_extension in ['.txt', '.md', '.json']:
                    raw_text = self._process_text_file(file_content)
                elif file_extension == '.pdf':
                    raw_text = self._process_pdf_file(file_content)
                elif file_extension in ['.doc', '.docx']:
                    raw_text = self._process_word_file(file_content)
                elif file_extension == '.csv':
                    raw_text = self._process_csv_file(file_content)
                elif file_extension in ['.xls', '.xlsx']:
                    raw_text = self._process_excel_file(file_content)
                elif file_extension in ['.mp3', '.wav', '.m4a']:
                    raw_text = self._process_audio_file(file_content, filename)
                elif file_extension in ['.mp4', '.avi', '.mov']:
                    raw_text = self._process_video_file(file_content, filename)
                else:
                    raise ValueError(f"Unsupported file type: {file_extension}")

                # Create chunks
                chunks = self._create_chunks(raw_text)
                
                return chunks

            finally:
                if temp_file and os.path.exists(temp_file.name):
                    os.unlink(temp_file.name)

        except Exception as e:
            self.logger.error(f"Error processing document {filename}: {str(e)}")
            raise

    def _process_text_file(self, content: bytes) -> str:
        """Process text files with multiple encoding attempts."""
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        
        for encoding in encodings:
            try:
                return content.decode(encoding)
            except UnicodeDecodeError:
                continue
                
        raise ValueError("Could not decode text file with any supported encoding")

    def _process_pdf_file(self, content: bytes) -> str:
        """Process PDF files with OCR fallback."""
        try:
            # Try PyPDF2 first
            pdf_file = io.BytesIO(content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text_content = []
            for page_num, page in enumerate(pdf_reader.pages):
                page_text = page.extract_text()
                if page_text.strip():
                    text_content.append(f"[Page {page_num + 1}]\n{page_text.strip()}")
            
            # If text extraction failed, use Textract
            if not any(text_content):
                return self._process_with_textract(content)
                
            return "\n\n".join(text_content)
            
        except Exception as e:
            self.logger.error(f"Error processing PDF: {str(e)}")
            return self._process_with_textract(content)

    def _process_word_file(self, content: bytes) -> str:
        """Process Word documents using Textract."""
        return self._process_with_textract(content)

    def _process_csv_file(self, content: bytes) -> str:
        """Process CSV files with multiple encoding support."""
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        
        for encoding in encodings:
            try:
                csv_file = io.StringIO(content.decode(encoding))
                df = pd.read_csv(csv_file)
                return self._format_dataframe(df)
            except Exception:
                continue
                
        raise ValueError("Could not process CSV file with any supported encoding")

    def _process_excel_file(self, content: bytes) -> str:
        """Process Excel files handling multiple sheets."""
        try:
            excel_file = io.BytesIO(content)
            
            # Get all sheet names
            xls = pd.ExcelFile(excel_file)
            sheets_text = []
            
            for sheet_name in xls.sheet_names:
                df = pd.read_excel(excel_file, sheet_name=sheet_name)
                sheets_text.append(f"\n[Sheet: {sheet_name}]\n")
                sheets_text.append(self._format_dataframe(df))
            
            return "\n\n".join(sheets_text)
            
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")

    def _is_supported_format(self, file_extension: str) -> bool:
        """Check if file format is supported."""
        all_formats = []
        for formats in self.config['supported_formats'].values():
            all_formats.extend(formats)
        return file_extension in all_formats

    def _extract_text(self, file: BinaryIO, file_extension: str, filename: str) -> str:
        """Extract text from document based on file type."""
        if file_extension in self.config['supported_formats']['document']:
            return self._process_document_file(file, file_extension)
        elif file_extension in self.config['supported_formats']['spreadsheet']:
            return self._process_spreadsheet_file(file, file_extension)
        elif file_extension in self.config['supported_formats']['audio']:
            return self._process_audio_file(file, filename)
        elif file_extension in self.config['supported_formats']['video']:
            return self._process_video_file(file, filename)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")

    def _process_document_file(self, file: BinaryIO, file_extension: str) -> str:
        """Process PDF or text document."""
        try:
            if file_extension == '.pdf':
                return self._process_pdf(file)
            elif file_extension in ['.txt', '.md']:
                return file.read().decode('utf-8')
            elif file_extension in ['.doc', '.docx']:
                return self._process_with_textract(file)
            else:
                raise ValueError(f"Unsupported document type: {file_extension}")
                
        except Exception as e:
            self.logger.error(f"Error processing document file: {str(e)}")
            raise

    def _process_pdf(self, file: BinaryIO) -> str:
        """Process PDF file using PyPDF2 and Textract for scanned documents."""
        try:
            # First try PyPDF2
            pdf_reader = PyPDF2.PdfReader(file)
            text = []
            
            # Process each page
            for page_num, page in enumerate(pdf_reader.pages):
                page_text = page.extract_text()
                if page_text.strip():
                    text.append(f"[Page {page_num + 1}]\n{page_text.strip()}\n")
            
            # If no text extracted, likely scanned PDF, use Textract
            if not any(text):
                self.logger.info("No text extracted with PyPDF2, trying Textract")
                return self._process_with_textract(file)
            
            return "\n".join(text)
            
        except Exception as e:
            self.logger.error(f"Error processing PDF: {str(e)}")
            raise

    def _process_with_textract(self, file: BinaryIO) -> str:
        """Process document using Amazon Textract."""
        temp_file = None
        try:
            # Create temporary file
            temp_file = tempfile.NamedTemporaryFile(delete=False)
            temp_file.write(file.read())
            temp_file.flush()
            
            # Process with Textract
            with open(temp_file.name, 'rb') as document:
                response = self.textract.detect_document_text(
                    Document={'Bytes': document.read()}
                )
            
            # Extract text with page information if available
            text_blocks = []
            current_page = 1
            for item in response['Blocks']:
                if item['BlockType'] == 'PAGE':
                    text_blocks.append(f"\n[Page {current_page}]\n")
                    current_page += 1
                elif item['BlockType'] == 'LINE':
                    text_blocks.append(item['Text'])
            
            return "\n".join(text_blocks)
            
        except Exception as e:
            self.logger.error(f"Error processing with Textract: {str(e)}")
            raise
        finally:
            if temp_file and os.path.exists(temp_file.name):
                os.unlink(temp_file.name)

    def _process_spreadsheet_file(self, file: BinaryIO, file_extension: str) -> str:
        """Process Excel or CSV file."""
        try:
            # Read file into pandas
            if file_extension == '.csv':
                df = pd.read_csv(io.StringIO(file.read().decode('utf-8')))
            else:  # Excel files
                df = pd.read_excel(file)
            
            # Process each sheet for Excel files
            if file_extension != '.csv':
                sheet_names = pd.ExcelFile(file).sheet_names
                sheets_text = []
                
                for sheet_name in sheet_names:
                    df = pd.read_excel(file, sheet_name=sheet_name)
                    sheets_text.append(f"\n[Sheet: {sheet_name}]\n")
                    sheets_text.append(self._format_dataframe(df))
                
                return "\n".join(sheets_text)
            else:
                return self._format_dataframe(df)
            
        except Exception as e:
            self.logger.error(f"Error processing spreadsheet: {str(e)}")
            raise

    def _format_dataframe(self, df: pd.DataFrame) -> str:
        """Format DataFrame content with error handling."""
        try:
            text_parts = []
            
            # Add column headers
            text_parts.append("Columns: " + " | ".join(str(col) for col in df.columns))
            
            # Add data rows with safe string conversion
            for index, row in df.iterrows():
                formatted_row = []
                for col, val in row.items():
                    # Safe string conversion for any data type
                    try:
                        if pd.isna(val):
                            formatted_val = "N/A"
                        else:
                            formatted_val = str(val)
                    except:
                        formatted_val = "Error"
                    formatted_row.append(f"{col}: {formatted_val}")
                
                text_parts.append(f"Row {index + 1}: " + " | ".join(formatted_row))
            
            return "\n".join(text_parts)
            
        except Exception as e:
            raise ValueError(f"Error formatting DataFrame: {str(e)}")

    def _process_audio_file(self, file: BinaryIO, filename: str) -> str:
        """Process audio file using Amazon Transcribe."""
        temp_path = None
        try:
            # Get temporary S3 path
            temp_bucket = self.config['s3_config'].get('temp_bucket', 'temp-transcription-bucket')
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            temp_path = f"temp/audio/{timestamp}_{filename}"
            
            # Upload to S3
            self.s3.upload_fileobj(file, temp_bucket, temp_path)
            
            # Start transcription
            job_name = f"transcribe_{timestamp}"
            file_format = os.path.splitext(filename)[1][1:]
            
            self.transcribe.start_transcription_job(
                TranscriptionJobName=job_name,
                Media={'MediaFileUri': f"s3://{temp_bucket}/{temp_path}"},
                MediaFormat=file_format,
                LanguageCode=self.config.get('transcribe_config', {}).get('language_code', 'en-US'),
                Settings={
                    'ShowSpeakerLabels': True,
                    'MaxSpeakerLabels': self.config.get('transcribe_config', {}).get('max_speakers', 10)
                }
            )
            
            # Wait for completion
            while True:
                response = self.transcribe.get_transcription_job(TranscriptionJobName=job_name)
                status = response['TranscriptionJob']['TranscriptionJobStatus']
                
                if status == 'COMPLETED':
                    transcript_uri = response['TranscriptionJob']['Transcript']['TranscriptFileUri']
                    transcript = requests.get(transcript_uri).json()
                    
                    # Format transcript with speaker labels and timestamps
                    segments = transcript['results']['speaker_labels']['segments']
                    items = transcript['results']['items']
                    
                    formatted_transcript = []
                    current_speaker = None
                    current_segment = []
                    
                    for item in items:
                        if 'start_time' in item:
                            speaker = next(
                                (seg['speaker_label'] for seg in segments
                                if float(seg['start_time']) <= float(item['start_time']) <= float(seg['end_time'])),
                                current_speaker
                            )
                            
                            if speaker != current_speaker:
                                if current_segment:
                                    formatted_transcript.append(f"Speaker {current_speaker}: {''.join(current_segment)}")
                                current_speaker = speaker
                                current_segment = []
                            
                            current_segment.append(item['alternatives'][0]['content'] + ' ')
                        else:
                            current_segment.append(item['alternatives'][0]['content'])
                    
                    if current_segment:
                        formatted_transcript.append(f"Speaker {current_speaker}: {''.join(current_segment)}")
                    
                    return '\n'.join(formatted_transcript)
                    
                elif status == 'FAILED':
                    raise Exception("Transcription job failed")
                
                time.sleep(5)
                
        except Exception as e:
            self.logger.error(f"Error processing audio file: {str(e)}")
            raise
        finally:
            if temp_path:
                try:
                    self.s3.delete_object(
                        Bucket=self.config['s3_config'].get('temp_bucket', 'temp-transcription-bucket'),
                        Key=temp_path
                    )
                except Exception as e:
                    self.logger.warning(f"Error cleaning up temporary file: {str(e)}")

    def _process_video_file(self, file: BinaryIO, filename: str) -> str:
        """Process video file using Amazon Transcribe Video."""
        # Implementation is similar to audio file processing
        return self._process_audio_file(file, filename)

    def _create_chunks(self, text: str) -> List[Dict]:
        """Create chunks from text with metadata."""
        try:
            splitter = RecursiveCharacterTextSplitter(
                chunk_size=self.config['chunk_size'],
                chunk_overlap=self.config['chunk_overlap'],
                separators=["\n\n", "\n", ". ", " ", ""],
                keep_separator=True
            )
            
            chunks = splitter.create_documents([text])
            
            formatted_chunks = []
            for i, chunk in enumerate(chunks):
                formatted_chunks.append({
                    'text': chunk.page_content,
                    'chunk_id': i,
                    'metadata': {
                        **chunk.metadata,
                        'chunk_size': len(chunk.page_content),
                        'chunk_number': i + 1
                    }
                })
            
            return formatted_chunks
            
        except Exception as e:
            raise ValueError(f"Error creating chunks: {str(e)}")

    def _generate_embeddings(self, chunks: List[Dict]) -> List[Dict]:
        """Generate embeddings with retries."""
        max_retries = 3
        retry_delay = 1
        
        for chunk in chunks:
            for attempt in range(max_retries):
                try:
                    response = self.bedrock.invoke_model(
                        modelId='amazon.titan-embed-text-v2:0',
                        contentType='application/json',
                        accept='application/json',
                        body=json.dumps({
                            'inputText': chunk['text']
                        })
                    )
                    
                    response_body = json.loads(response['body'].read().decode())
                    chunk['embedding'] = response_body['embedding']
                    break
                    
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    time.sleep(retry_delay)
        
        return chunks

    def _detect_pii(self, text: str) -> List[Dict]:
        """Detect PII using Amazon Comprehend."""
        try:
            if not text:
                return []
                
            # Break text into smaller chunks if it's too long
            max_length = 5000  # Comprehend's limit
            if len(text) > max_length:
                text = text[:max_length]
            
            response = self.comprehend.detect_pii_entities(
                Text=text,
                LanguageCode='en'
            )
            
            return response['Entities']
            
        except Exception as e:
            self.logger.error(f"Error detecting PII: {str(e)}")
            return []

    def _redact_pii(self, text: str, pii_entities: List[Dict]) -> str:
        """Redact PII from text."""
        try:
            if not pii_entities:
                return text
            
            redacted_text = text
            # Sort entities in reverse order to avoid offset issues
            sorted_entities = sorted(
                pii_entities,
                key=lambda x: x['BeginOffset'],
                reverse=True
            )
            
            for entity in sorted_entities:
                start = entity['BeginOffset']
                end = entity['EndOffset']
                entity_type = entity['Type']
                
                # Replace PII with placeholder
                redacted_text = (
                    redacted_text[:start] +
                    f"[REDACTED:{entity_type}]" +
                    redacted_text[end:]
                )
            
            return redacted_text
            
        except Exception as e:
            self.logger.error(f"Error redacting PII: {str(e)}")
            return text

    def process_document_with_options(
        self,
        file: BinaryIO,
        filename: str,
        handle_pii: bool = False,
        language_detection: bool = True,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None
    ) -> List[Dict]:
        """Process document with configurable options."""
        try:
            # Store original config
            original_config = {
                'chunk_size': self.config['chunk_size'],
                'chunk_overlap': self.config['chunk_overlap'],
                'pii_handling': self.config.get('pii_handling', {}).copy()
            }
            
            # Apply temporary config changes
            if chunk_size:
                self.config['chunk_size'] = chunk_size
            if chunk_overlap:
                self.config['chunk_overlap'] = chunk_overlap
            
            self.config['pii_handling'] = {
                'enable_detection': handle_pii,
                'enable_redaction': handle_pii
            }
            
            # Process document
            chunks = self.process_document(file, filename)
            
            # Restore original config
            self.config.update(original_config)
            
            return chunks
            
        except Exception as e:
            self.logger.error(f"Error processing document with options: {str(e)}")
            # Restore original config in case of error
            self.config.update(original_config)
            raise

    def validate_document(self, file: BinaryIO, filename: str) -> Dict:
        """Validate document before processing."""
        try:
            validation_results = {
                'is_valid': True,
                'file_size': file.seek(0, 2),  # Get file size
                'extension': os.path.splitext(filename)[1].lower(),
                'errors': [],
                'warnings': []
            }
            
            # Reset file pointer
            file.seek(0)
            
            # Check file size
            max_size = self.config.get('max_file_size_mb', 100) * 1024 * 1024
            if validation_results['file_size'] > max_size:
                validation_results['is_valid'] = False
                validation_results['errors'].append(
                    f"File size ({validation_results['file_size'] / (1024*1024):.2f}MB) "
                    f"exceeds maximum allowed size ({max_size / (1024*1024)}MB)"
                )
            
            # Check file extension
            if not self._is_supported_format(validation_results['extension']):
                validation_results['is_valid'] = False
                validation_results['errors'].append(
                    f"Unsupported file format: {validation_results['extension']}"
                )
            
            # Additional format-specific validation
            if validation_results['extension'] == '.pdf':
                try:
                    pdf_reader = PyPDF2.PdfReader(file)
                    validation_results['page_count'] = len(pdf_reader.pages)
                    
                    # Check if PDF is encrypted
                    if pdf_reader.is_encrypted:
                        validation_results['is_valid'] = False
                        validation_results['errors'].append("PDF file is encrypted")
                    
                except Exception as e:
                    validation_results['is_valid'] = False
                    validation_results['errors'].append(f"Invalid PDF file: {str(e)}")
            
            return validation_results
            
        except Exception as e:
            self.logger.error(f"Error validating document: {str(e)}")
            return {
                'is_valid': False,
                'errors': [str(e)]
            }

    def cleanup_temporary_files(self):
        """Clean up any temporary files or resources."""
        try:
            # Clean up temp S3 bucket
            temp_bucket = self.config['s3_config'].get('temp_bucket', 'temp-transcription-bucket')
            
            # List and delete objects in temp folder
            response = self.s3.list_objects_v2(
                Bucket=temp_bucket,
                Prefix='temp/'
            )
            
            if 'Contents' in response:
                for obj in response['Contents']:
                    if (datetime.now() - obj['LastModified']).days > 1:  # Delete files older than 1 day
                        self.s3.delete_object(
                            Bucket=temp_bucket,
                            Key=obj['Key']
                        )
            
        except Exception as e:
            self.logger.error(f"Error cleaning up temporary files: {str(e)}")