import streamlit as st
import pandas as pd
import json
import pygwalker as pyg
from src.services.s3_service import S3Service
from pygwalker.api.streamlit import StreamlitRenderer

class DataInsightsUI:
    def __init__(self, common_config: dict):
        """Initialize DataInsightsUI with configuration."""
        self.common_config = common_config
        self.s3_service = S3Service(common_config['s3_config'])
        
        # Initialize session state for selections
        if 'selected_main_tab' not in st.session_state:
            st.session_state.selected_main_tab = None
        if 'selected_sub_tab' not in st.session_state:
            st.session_state.selected_sub_tab = None
            
        # Initialize analysis state
        if 'analysis_state' not in st.session_state:
            st.session_state.analysis_state = {
                'data_loaded': False,
                'current_dataset': None,
                'error_message': None
            }

    def _get_sub_tabs(self, main_tab: str) -> list:
        """Get corresponding sub-tabs based on selected main tab."""
        tabs_config = self.common_config['tabs_config']
        
        if main_tab == "Final Summary":
            return tabs_config['final_summary_tabs']
        elif main_tab == "Working Summary":
            return tabs_config['working_summary_tabs']
        return []

    def _construct_s3_path(self, sub_tab: str) -> str:
        """Construct S3 path for the selected tab's data file."""
        bucket = self.common_config['s3_config']['bucket']
        main_folder = self.common_config['s3_config']['main_folder']
        year = st.session_state.get('driver_year', '2024')
        period = st.session_state.get('driver_period', 'Q3')
        
        # Convert tab name to filename format
        file_name = f"{sub_tab.lower().replace(' ', '_')}_{year}_{period}_response.json"
        
        return f"s3://{bucket}/{main_folder}/working_summary/{file_name}"

    def _clean_numeric_string(self, value: str) -> str:
        """Clean numeric string by removing special characters."""
        if isinstance(value, str):
            # Remove parentheses, % symbols, and currency symbols
            value = value.replace('(', '-').replace(')', '').replace('%', '').replace('£', '').strip()
            # Handle empty or invalid values
            return value if value else '0'
        return str(value)

    def _load_and_process_data(self, s3_path: str) -> pd.DataFrame:
        """Load and process data from S3 JSON file into pandas DataFrame."""
        try:
            # Get file content from S3
            content = self.s3_service.get_document_content(s3_path)
            if not content:
                st.session_state.analysis_state['error_message'] = "No content found in S3"
                return None

            # Parse JSON content
            json_data = json.loads(content.decode('utf-8'))
            
            # Extract data array from JSON
            data_array = json_data.get('data', [])
            if not data_array:
                st.session_state.analysis_state['error_message'] = "No data array found in JSON"
                return None

            # Convert to DataFrame
            df = pd.DataFrame(data_array)
            
            # Use first row as headers and remove it from data
            if not df.empty:
                df.columns = df.iloc[0]
                df = df[1:]
                
                # Remove empty rows and rows with all empty values
                df = df[df.iloc[:, 0] != ""]
                df = df.dropna(how='all')
                
                # Reset index
                df = df.reset_index(drop=True)
                
                # Clean and convert numeric columns
                for col in df.columns:
                    try:
                        # Clean numeric strings
                        df[col] = df[col].apply(self._clean_numeric_string)
                        # Attempt numeric conversion
                        df[col] = pd.to_numeric(df[col], errors='ignore')
                    except Exception as e:
                        print(f"Error converting column {col}: {str(e)}")
                        continue

                # Update state
                st.session_state.analysis_state['data_loaded'] = True
                st.session_state.analysis_state['current_dataset'] = s3_path
                st.session_state.analysis_state['error_message'] = None
                
                return df
            else:
                st.session_state.analysis_state['error_message'] = "Empty DataFrame after processing"
                return None
                
        except Exception as e:
            st.session_state.analysis_state['error_message'] = f"Error loading data: {str(e)}"
            return None

    def _render_insights_header(self):
        """Render the insights header section."""
        st.markdown("### Data Insights Explorer")
        
        # Add description with styling
        st.markdown("""
        <div style='background-color: #f0f2f6; padding: 15px; border-radius: 5px; margin-bottom: 20px;'>
            <h4 style='color: #0051A2; margin-top: 0;'>Interactive Data Analysis</h4>
            <p>Explore your financial data using this interactive visualization tool. Follow these steps:</p>
            <ol>
                <li>Select the main category (Final Summary or Working Summary)</li>
                <li>Choose a specific report type</li>
                <li>Use the interactive dashboard below to:</li>
                <ul>
                    <li>Create custom charts and visualizations</li>
                    <li>Filter and sort data</li>
                    <li>Perform trend analysis</li>
                    <li>Export insights</li>
                </ul>
            </ol>
        </div>
        """, unsafe_allow_html=True)

    def _render_pygwalker(self, df: pd.DataFrame):
        """Render PyGWalker visualization."""
        try:
            # Configure PyGWalker
            config = {
                "dataframe": df,
                "spec": "config.json",  # Default spec
                "debug": False
            }
            
            # Initialize the PyGWalker Streamlit renderer
            renderer = StreamlitRenderer(df, spec="./gw_config.json", spec_io_mode="rw")
            renderer.explorer(default_tab="data")
            
        except Exception as e:
            st.error(f"Error rendering visualization: {str(e)}")

    def render(self):
        """Render the Data Insights interface."""
        self._render_insights_header()
        
        # Create filters in columns
        col1, col2 = st.columns(2)
        
        with col1:
            # Main tab selection
            main_tabs = [tab for tab in self.common_config['tabs_config']['main_tabs'] if tab != "Data Insights"]
            selected_main_tab = st.selectbox(
                "Select Main Category",
                options=[""]+main_tabs,
                key="main_tab_selector"
            )

        with col2:
            # Sub tab selection based on main tab
            sub_tabs = self._get_sub_tabs(selected_main_tab)
            selected_sub_tab = st.selectbox(
                "Select Report Type",
                options=[""]+sub_tabs,
                key="sub_tab_selector"
            )

        # Update session state
        st.session_state.selected_main_tab = selected_main_tab
        st.session_state.selected_sub_tab = selected_sub_tab

        # Add a divider
        st.markdown("<hr>", unsafe_allow_html=True)

        # Load and display data when both selections are made
        if selected_main_tab and selected_sub_tab:
            s3_path = self._construct_s3_path(selected_sub_tab)
            
            # Show loading spinner
            with st.spinner('Loading and processing data...'):
                df = self._load_and_process_data(s3_path)
            
            if df is not None and not df.empty:
                # Display data summary
                st.markdown("### Dataset Summary")
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.info(f"Total Records: {len(df)}")
                with col2:
                    st.info(f"Numeric Columns: {len(df.select_dtypes(include=['number']).columns)}")
                with col3:
                    st.info(f"Text Columns: {len(df.select_dtypes(include=['object']).columns)}")
                with col4:
                    st.info(f"Memory Usage: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

                # Add spacing
                st.markdown("<br>", unsafe_allow_html=True)
                
                # Display PyGWalker visualization
                st.markdown("### Interactive Data Explorer")
                st.markdown("""
                    Use the tools below to:
                    - Create various chart types (bar, line, scatter, etc.)
                    - Filter and aggregate data
                    - Export visualizations
                """)
                
                # Render PyGWalker visualization
                self._render_pygwalker(df)
            else:
                error_msg = st.session_state.analysis_state.get('error_message', 'No data available for the selected options.')
                st.error(error_msg)