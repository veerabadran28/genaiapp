import streamlit as st
import pandas as pd
import os
import time
from typing import Dict, Optional
import json
import boto3

class SummaryAnalysisUI:
    def __init__(self, common_config: Dict, bank_configs: Dict, bedrock_service, data_processor):
        self.common_config = common_config
        self.bank_configs = bank_configs
        self.bedrock_service = bedrock_service
        self.data_processor = data_processor

    def render(self):
        """Render the Summary Analysis interface."""
        # Apply static styling
        st.markdown("""
            <style>
            .stButton > button {
                background-color: #0051A2;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                cursor: pointer;
            }
            .section-header {
                background-color: #006A4D;
                color: white;
                padding: 10px 15px;
                margin-bottom: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            .dataframe th {
                background-color: #006A4D !important;
                color: white !important;
                text-align: center !important;
            }
            .dataframe td {
                padding: 8px !important;
            }
            .stTabs [data-baseweb="tab"] {
                background-color: #f8f9fa; /* Default tab color */
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            .stTabs [data-baseweb="tab"][aria-selected="true"] {
                background-color: #0051A2 !important; /* Highlighted tab color */
                color: white !important;
            }
            </style>
        """, unsafe_allow_html=True)

        # Render header
        col1, col2, col3 = st.columns([0.1, 10.5, 1])
        with col2:
            st.markdown("### Summary Analysis")
        with col3:
            if st.button("← Back", key="summary_back", use_container_width=True):
                st.session_state.current_view = 'main'
                st.rerun()

        # Main tabs from config
        main_tabs = st.tabs(self.common_config['tabs_config']['main_tabs'])

        with main_tabs[0]:  # Final Summary
            self._render_final_summary()

        with main_tabs[1]:  # Working Summary
            self._render_working_summary()

    def get_selected_bank(self) -> Optional[str]:
        """Get the currently selected bank."""
        if 'selected_bank' not in st.session_state:
            working_summary_tabs = self.common_config['tabs_config']['working_summary_tabs']
            for bank_name in working_summary_tabs:
                bank_id = self._get_bank_id(bank_name)
                if self.bank_configs[bank_id]['bank_info'].get('implementation_status') == 'active':
                    st.session_state.selected_bank = bank_id
                    break
        return st.session_state.get('selected_bank')
    
    def _get_bank_id(self, bank_name: str) -> str:
        """Convert bank name to bank ID format."""
        return bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')

    def _render_working_summary(self):
        """Render Working Summary section using working_summary_tabs from config."""
        # Get tabs from config
        working_summary_tabs = self.common_config['tabs_config']['working_summary_tabs']
        tabs = st.tabs(working_summary_tabs)

        for bank_name, tab in zip(working_summary_tabs, tabs):
            with tab:
                bank_id = self._get_bank_id(bank_name)
                bank_config = self.bank_configs.get(bank_id)
                
                if bank_config and bank_config['bank_info'].get('implementation_status') == 'active':
                    st.session_state.selected_bank = bank_id
                    self._render_bank_analysis(bank_config)
                else:
                    st.info(f"Implementation pending for {bank_name}")

    def _render_bank_analysis(self, bank_config: Dict):
        """Render bank analysis section."""
        try:
            # Display bank logo
            st.image(bank_config['bank_info']['logo_url'], width=200)

            # Process files from config
            for file_config in bank_config['file_config']['files']:
                # Get absolute path
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                file_path = os.path.join(base_dir, file_config['path'])
                
                if not os.path.exists(file_path):
                    st.error(f"File not found: {file_path}")
                    return

                # Load and process data
                data = pd.read_excel(file_path, sheet_name=file_config['sheet_name'])
                cleaned_df = data.dropna(how="all")
                
                # Create tabs from config
                tab1, tab2 = st.tabs(["Summary", "Data Preview"])

                # Summary Tab
                with tab1:
                    self._render_summary_tab(cleaned_df, bank_config)

                # Data Preview Tab
                with tab2:
                    st.markdown("### Raw Data Preview")
                    st.dataframe(cleaned_df)

            # Footer
            st.markdown("<hr style='margin: 15px 0px; border: 1px solid #00b8e6'>", unsafe_allow_html=True)
            st.markdown(
                "<div style='text-align: center; color: #666666;'>Financial Data Transformer | Powered by AWS Bedrock Claude 3.5 Sonnet</div>",
                unsafe_allow_html=True
            )

        except Exception as e:
            st.error(f"Error: {str(e)}")
            st.exception(e)

    def _render_summary_tab(self, data: pd.DataFrame, bank_config: Dict):
        """Render summary tab content."""
        if "data_processed" not in st.session_state:
            st.session_state.data_processed = False

        if st.button("Process Data", use_container_width=True):
            with st.spinner("Processing financial data..."):
                json_response = self.process_data(data, bank_config)

                if not json_response or "data" not in json_response:
                    st.error("Failed to process data or no response received.")
                    return

                # Safely get datasets from bank_config
                dataset_configs = bank_config.get('datasets', {})
                if not dataset_configs:
                    st.error("Dataset configuration is missing in bank config.")
                    return

                datasets = self.parse_datasets(json_response, dataset_configs)
                st.session_state.datasets = datasets
                st.session_state.data_processed = True
                st.session_state.json_response = json_response

        if st.session_state.data_processed:
            with st.expander("JSON Response from Claude"):
                st.json(st.session_state.json_response)

            if "datasets" in st.session_state:
                self.display_datasets(st.session_state.datasets, bank_config)

            st.success("✅ Data processed successfully!")
    
    def load_prompt(self, prompt_file_path: str) -> str:
        """Load the prompt content from the specified file."""
        if not os.path.exists(prompt_file_path):
            raise FileNotFoundError(f"Prompt file not found: {prompt_file_path}")
        with open(prompt_file_path, 'r', encoding='utf-8') as file:
            return file.read()

    def process_data(self, data: pd.DataFrame, bank_config: Dict) -> Optional[Dict]:
        """Process the data using Bedrock service."""
        try:
            # Convert DataFrame to a string representation
            data_str = data.to_string(index=False)

            # Load and prepare the prompt
            prompt_file_path = bank_config['bank_info'].get('prompt_file')
            if not prompt_file_path:
                raise ValueError("Prompt file path is not configured.")

            # Resolve the path relative to the current working directory (competitor_analysis)
            absolute_prompt_path = os.path.join(os.getcwd(), prompt_file_path)

            # Check if the file exists
            if not os.path.exists(absolute_prompt_path):
                raise FileNotFoundError(f"Prompt file not found: {absolute_prompt_path}")

            # Load the prompt template
            prompt_template = self.load_prompt(absolute_prompt_path)
            with st.expander("Prompt Template"):
                st.write(prompt_template)
                
            # Format the prompt with the data
            prompt = prompt_template.format(formatted_data=data_str)
            
            # Invoke the Bedrock model
            return self.bedrock_service.invoke_model(prompt)

        except Exception as e:
            st.error(f"Error processing data: {str(e)}")
            return None

    def parse_datasets(self, json_response: Dict, dataset_configs: Dict) -> Dict[str, pd.DataFrame]:
        """Parse datasets based on configuration."""
        datasets = {}
        current_dataset = None
        headers = None
        records = []

        for row in json_response.get("data", []):
            dataset_names = [config["name"] for config in dataset_configs.values()]
            if len(row) > 0 and row[0] in dataset_names:
                if current_dataset and headers and records:
                    datasets[current_dataset] = pd.DataFrame(records, columns=headers)
                current_dataset = row[0]
                headers = row
                records = []
            elif len(row) > 1:
                records.append(row)

        if current_dataset and headers and records:
            datasets[current_dataset] = pd.DataFrame(records, columns=headers)

        return datasets

    def display_datasets(self, datasets: Dict[str, pd.DataFrame], bank_config: Dict):
        """Display datasets according to configuration."""
        if not datasets:
            st.warning("No datasets available to display.")
            return

        for name, df in datasets.items():
            if df.empty:
                st.warning(f"{name} is empty and will not be displayed.")
                continue

            st.markdown(f'<div class="section-header">{name}</div>', unsafe_allow_html=True)
            st.dataframe(df, use_container_width=True)

        if "json_response" in st.session_state:
            self.create_download_file(datasets, bank_config)

    def create_download_file(self, datasets: Dict[str, pd.DataFrame], bank_config: Dict):
        """Create a downloadable file with headers included."""
        try:
            combined_data = []

            for dataset_name, df in datasets.items():
                if not df.empty:
                    # Add the dataset name as a header
                    combined_data.append([dataset_name])  # Dataset title as a row
                    combined_data.append(list(df.columns))  # Add column headers
                    combined_data.extend(df.values.tolist())  # Add data rows
                    combined_data.append([])  # Blank row for separation

            # Convert combined data to a DataFrame for CSV export
            combined_df = pd.DataFrame(combined_data)

            # Generate a timestamped filename
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            file_name = f"{bank_config['file_config']['output_prefix']}_{timestamp}.csv"

            # Create a download button
            st.download_button(
                label=f"Download {file_name}",
                data=combined_df.to_csv(index=False, header=False).encode("utf-8"),
                file_name=file_name,
                mime="text/csv"
            )
        except Exception as e:
            st.error(f"Error creating the download file: {str(e)}")

    def _render_final_summary(self):
        """Render Final Summary section."""
        # Get tabs from config
        final_summary_tabs = self.common_config['tabs_config']['final_summary_tabs']
        tabs = st.tabs(final_summary_tabs)
        
        for tab in tabs:
            with tab:
                st.info("Implementation pending for this section.")