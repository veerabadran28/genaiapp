import PyPDF2
import re
import io
from typing import Dict, List, Optional

class PDFProcessor:
    def __init__(self, pdf_content: bytes):
        self.pdf_content = pdf_content
        self.pdf_reader = PyPDF2.PdfReader(io.BytesIO(pdf_content))

    def extract_section(self, start_marker: str, end_marker: str) -> str:
        """Extract section from PDF between markers."""
        full_text = ""
        section_text = ""
        found_start = False
        
        # First get full text
        for page in self.pdf_reader.pages:
            full_text += page.extract_text() + "\n"
            
        # Find section using markers
        start_idx = full_text.find(start_marker)
        if start_idx != -1:
            text_after_start = full_text[start_idx:]
            end_idx = text_after_start.find(end_marker)
            if end_idx != -1:
                section_text = text_after_start[:end_idx].strip()
        
        return section_text

    def extract_table_data(self, section_text: str) -> str:
        """Convert table-like text to CSV format."""
        lines = section_text.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Clean and normalize numbers
            line = re.sub(r'\s+', ' ', line).strip()
            # Convert parentheses to negative numbers
            line = re.sub(r'\((\d+)\)', r'-\1', line)
            cleaned_lines.append(line)
            
        return '\n'.join(cleaned_lines)

    def process_sections(self, sections: List[Dict]) -> Dict[str, str]:
        """Process each section defined in config."""
        results = {}
        
        for section in sections:
            #print(f"section:{section}")
            section_text = self.extract_section(
                section['start_marker'],
                section['end_marker']
            )
            if section_text:
                #print(f"section_text:{section_text}")
                table_data = self.extract_table_data(section_text)
                results[section['data_key']] = table_data
        #print(f"results:{results}")
        return results