import streamlit as st
from typing import Dict, List
import pandas as pd
import json
import re

class FinancialChatBot:
    def __init__(self, datasets: Dict[str, pd.DataFrame], model_response: Dict, bank_info: Dict, bedrock_service, additional_docs: Dict = None):
        self.datasets = datasets
        self.model_response = model_response
        self.bank_info = bank_info
        self.bedrock_service = bedrock_service
        self.additional_docs = additional_docs or {}
        self.greetings = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening']
        self.context = None
        self.bank_id = bank_info['tab_name'].lower().replace(' ', '_').replace('(', '').replace(')', '')

    def _is_greeting(self, text: str) -> bool:
        """Check if the input is a greeting."""
        return any(greeting in text.lower() for greeting in self.greetings)

    def _get_greeting_response(self) -> Dict:
        """Get appropriate greeting response."""
        return {
            'response': f"Hello! I'm your financial analysis assistant for {self.bank_info.get('name')}. I can help you understand the financial metrics and KPIs in the processed data. What would you like to know about?",
            'follow_up': [
                "You can ask about:",
                "- Latest financial performance",
                "- Key metrics comparison",
                "- Balance sheet analysis"
            ],
            'type': 'greeting'
        }

    def _find_relevant_info(self, query: str) -> List[Dict]:
        """Find strictly relevant information from data sources."""
        if self._is_greeting(query):
            return []

        relevant_info = []
        query_terms = query.lower().split()
        
        # Get the combined DataFrame
        df = self.datasets.get('combined')
        if df is None:
            return []
            
        current_section = None
        metrics = {}
        
        # Process row by row to understand the structure
        for idx, row in df.iterrows():
            row_data = row.dropna().tolist()
            if len(row_data) == 0:
                continue
                
            if len(row_data) == 1:  # This is a section header
                current_section = row_data[0]
                continue
                
            if current_section and len(row_data) > 1:
                # First column is metric name, rest are values
                metric_name = row_data[0]
                values = row_data[1:]
                
                # Check if this metric matches the query
                if any(term in metric_name.lower() for term in query_terms):
                    metrics[metric_name] = {
                        'section': current_section,
                        'values': values
                    }

        # Convert matched metrics to relevant_info format
        for metric_name, data in metrics.items():
            relevant_info.append({
                'source': data['section'],
                'metric': metric_name,
                'data': dict(enumerate(data['values'])),  # Create a dict with indices as keys
                'type': 'metric',
                'confidence': 'high' if any(term == metric_name.lower() for term in query_terms) else 'medium'
            })

        return relevant_info

    def _prepare_claude_messages(self, query: str, relevant_info: List[Dict]) -> List[Dict]:
        """Prepare messages for Claude with context and query."""
        system_message = {
            "role": "system",
            "content": [
                {
                    "type": "text",
                    "text": f"""You are a financial analyst assistant for {self.bank_info.get('name')}. 
                    Answer questions about financial data in a concise, human-like way.
                    Format your response as a JSON object with these fields:
                    {{
                        "response": "your concise response here",
                        "follow_up": ["relevant follow-up question 1", "relevant follow-up question 2"],
                        "type": "data_response"
                    }}"""
                }
            ]
        }

        # Prepare context content more structuredly
        context = f"Here's the financial data for {self.bank_info.get('name')}:\n\n"
        for info in relevant_info:
            context += f"Dataset: {info['source']}\n"
            context += f"Metric: {info['metric']}\n"
            context += "Values:\n"
            for period, value in info['data'].items():
                if pd.notnull(value):  # Skip NaN values
                    context += f"{period}: {value}\n"
            context += "\n"

        user_message = {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": f"{context}\n\nQuestion: {query}\n\nProvide a concise, human-like response that directly answers the question and explains any significant changes or trends if relevant."
                }
            ]
        }

        return [system_message, user_message]

    def get_response(self, query: str) -> Dict:
        """Generate response using Bedrock Claude."""
        if self._is_greeting(query):
            return self._get_greeting_response()

        try:
            # Get the combined DataFrame
            df = self.datasets.get('combined')
            if df is None:
                return {
                    'response': "I don't have access to the financial data at the moment.",
                    'follow_up': [
                        "Please try again later or check with support."
                    ],
                    'type': 'error'
                }

            # Prepare context with all data
            system_message = {
                "role": "system",
                "content": [
                    {
                        "type": "text",
                        "text": f"""You are a financial analyst assistant for {self.bank_info.get('name')}. 
                        Provide direct, concise answers with simple comparisons.
                        Keep responses brief and conversational.
                        Only provide additional details if specifically asked.

                        Format your response as a JSON object with these fields:
                        {{
                            "response": "your brief answer",
                            "follow_up": ["suggest 2 relevant follow-up questions"],
                            "type": "data_response"
                        }}

                        Example responses:
                        - "NII is £2,475m in H124, down from £2,908m in H123."
                        - "Cost Income Ratio is 54% in Q224, up from 52% in Q124."
                        No detailed analysis unless specifically asked."""
                    }
                ]
            }

            # Convert DataFrame to structured text
            financial_data = df.to_string(index=False)
            
            user_message = {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"Financial Data:\n{financial_data}\n\nQuestion: {query}"
                    }
                ]
            }

            # Send to Claude
            messages = [system_message, user_message]
            claude_response = self.bedrock_service.invoke_model(messages)
            
            if claude_response and 'content' in claude_response:
                try:
                    # Parse JSON response
                    response_data = json.loads(claude_response['content'])
                    return response_data
                except json.JSONDecodeError:
                    return {
                        'response': claude_response['content'],
                        'follow_up': [
                            "Would you like to know about:",
                            "- Latest performance metrics",
                            "- Balance sheet metrics"
                        ],
                        'type': 'data_response'
                    }
            else:
                return {
                    'response': "I understand you're asking about " + query + ", but I'm having trouble processing the response. Could you try rephrasing your question?",
                    'follow_up': [
                        "Try asking about:",
                        "- Recent financial metrics",
                        "- Specific time periods"
                    ],
                    'type': 'error'
                }
                
        except Exception as e:
            st.error(f"Error processing response: {str(e)}")
            return {
                'response': "I apologize, but I'm having trouble analyzing the data right now. Please try again.",
                'follow_up': [
                    "In the meantime, you can:",
                    "- Try a different question",
                    "- Check the raw data above"
                ],
                'type': 'error'
            }

    def render_chat_interface(self):
        """Render the chat interface."""
        st.markdown("""
            <style>
            /* Container styling */
            [data-testid="stVerticalBlockBorderWrapper"] {
                background-color: #f8f9fa !important;  /* Light gray background for main container */
                border-radius: 10px !important;
                padding: 10px !important;
            }
            
            .chat-header {
                background-color: #0051A2;
                color: white;
                padding: 12px 15px;
                border-radius: 8px;
                font-weight: bold;
                margin-bottom: 10px;
            }
            
            .chat-message {
                margin: 8px 0;
                padding: 12px;
                border-radius: 8px;
                max-width: 85%;
                word-wrap: break-word;
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            }
            
            .user-message {
                background-color: #e3f2fd;  /* Light blue for user messages */
                margin-left: 15%;
                align-self: flex-end;
                color: #0d47a1;  /* Darker blue for user text */
            }
            
            .bot-message {
                background-color: #ffffff;  /* White background for bot messages */
                margin-right: 15%;
                border: 1px solid #e0e0e0;
                align-self: flex-start;
                color: #333333;  /* Dark gray for bot text */
            }
            
            .follow-up {
                font-size: 0.9em;
                color: #666666;
                margin-top: 8px;
                padding-top: 8px;
                border-top: 1px solid #eeeeee;
            }
            
            /* Input field styling */
            .stTextInput > div > div > input {
                background-color: white;
                max-width: 100%;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                padding: 8px 12px;
            }
            
            .stTextInput > div {
                padding: 0;
            }
            
            .stTextInput > label {
                display: none;
            }
            
            /* Remove default Streamlit padding */
            .main > div {
                padding: 0;
            }
            </style>
        """, unsafe_allow_html=True)

        # Initialize chat states with bank-specific keys
        chat_history_key = f"chat_history_{self.bank_id}"
        user_input_key = f"user_input_{self.bank_id}"
        chat_input_key = f"chat_input_{self.bank_id}"

        if chat_history_key not in st.session_state:
            st.session_state[chat_history_key] = []
            # Add initial greeting
            greeting_response = self._get_greeting_response()
            st.session_state[chat_history_key].append({
                "role": "assistant",
                "content": greeting_response['response'],
                "follow_up": greeting_response['follow_up']
            })

        # Initialize message state
        if user_input_key not in st.session_state:
            st.session_state[user_input_key] = ""

        # Chat header
        st.markdown('<div class="chat-header">Financial Analysis Assistant</div>', unsafe_allow_html=True)
        
        # Main chat container with border and fixed height
        with st.container(border=True, height=550):
            # Messages container
            with st.container(border=False, height=450):
                for message in st.session_state[chat_history_key]:
                    if message["role"] == "user":
                        st.markdown(
                            f'<div class="chat-message user-message">🤵 {message["content"]}</div>', 
                            unsafe_allow_html=True
                        )
                    else:
                        message_html = f'<div class="chat-message bot-message">🤖 {message["content"]}'
                        if "follow_up" in message:
                            message_html += f'<div class="follow-up">{chr(10).join(message["follow_up"])}</div>'
                        message_html += '</div>'
                        st.markdown(message_html, unsafe_allow_html=True)

            # Initialize input state
            if chat_input_key not in st.session_state:
                st.session_state[chat_input_key] = ""

            def submit():
                if st.session_state[chat_input_key].strip():
                    user_message = st.session_state[chat_input_key]
                    
                    # Add user message to history
                    st.session_state[chat_history_key].append({
                        "role": "user",
                        "content": user_message
                    })
                    
                    # Get bot response
                    response_data = self.get_response(user_message)
                    
                    # Add bot response to history
                    st.session_state[chat_history_key].append({
                        "role": "assistant",
                        "content": response_data['response'],
                        "follow_up": response_data['follow_up']
                    })
                    
                    # Clear input
                    st.session_state[user_input_key] = ""
                    st.session_state[chat_input_key] = ""

            # Text input with submit handler
            st.text_input(
                "Ask about the financial data:",
                key=chat_input_key,
                on_change=submit,
                value=st.session_state[user_input_key],
                placeholder="Ask me questions here...!"
            )