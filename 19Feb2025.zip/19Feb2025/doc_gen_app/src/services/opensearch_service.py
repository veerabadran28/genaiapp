import boto3
import json
from typing import Dict, List
import requests
from requests_aws4auth import AWS4Auth
import logging
from datetime import datetime

class OpenSearchService:
    def __init__(self, config: Dict):
        """Initialize OpenSearch service with configuration."""
        # Remove 'https://' if it exists in the endpoint
        self.endpoint = config['endpoint'].replace('https://', '')
        self.index = config['index']
        self.region = config.get('region', 'us-east-1')
        self.embedding_dimension = 1024  # Titan v2 embedding dimension
        self.service = 'es'
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        
        # Setup AWS auth
        self.credentials = self._get_credentials()
        self.auth = AWS4Auth(
            self.credentials.access_key,
            self.credentials.secret_key,
            self.region,
            self.service,
            session_token=self.credentials.token
        )
        
        # Create index if it doesn't exist
        self._create_index_if_not_exists()

    def _get_url(self, path: str = '') -> str:
        """Construct OpenSearch URL."""
        return f"https://{self.endpoint}/{path.lstrip('/')}"

    def _get_credentials(self):
        """Get AWS credentials."""
        session = boto3.Session()
        return session.get_credentials()

    def _get_headers(self):
        """Get headers for OpenSearch requests."""
        return {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

    def _create_index_if_not_exists(self):
        """Create OpenSearch index with proper mapping for embeddings."""
        try:
            # Check if index exists
            url = f"https://{self.endpoint}/{self.index}"
            response = requests.head(url, auth=self.auth)

            # Log the response for debugging
            print(f"HEAD response status code: {response.status_code}")
            print(f"HEAD response headers: {response.headers}")

            if response.status_code == 404:
                # Create index with mapping
                mapping = {
                    "settings": {
                        "index": {
                            "knn": True,
                            "knn.algo_param.ef_search": 100
                        }
                    },
                    "mappings": {
                        "properties": {
                            "content": {
                                "type": "text",
                                "analyzer": "standard"
                            },
                            "embedding": {
                                "type": "knn_vector",
                                "dimension": 1024,
                                "method": {
                                    "name": "hnsw",
                                    "space_type": "l2",
                                    "engine": "nmslib",
                                    "parameters": {
                                        "ef_construction": 128,
                                        "m": 16
                                    }
                                }
                            },
                            "source": {
                                "type": "keyword"
                            },
                            "chunk_id": {
                                "type": "integer"
                            },
                            "page_number": {
                                "type": "integer"
                            },
                            "metadata": {
                                "properties": {
                                    "bank": {"type": "keyword"},
                                    "year": {"type": "keyword"},
                                    "period": {"type": "keyword"},
                                    "filename": {"type": "keyword"}
                                }
                            }
                        }
                    }
                }

                response = requests.put(
                    url,
                    auth=self.auth,
                    headers=self._get_headers(),
                    data=json.dumps(mapping)
                )
                print(f"Response: {response.status_code} - {response.text}")
                if not response.ok:
                    raise Exception(f"Failed to create index: {response.text}")

                self.logger.info(f"Successfully created index: {self.index}")

            elif response.status_code == 200:
                self.logger.info(f"Index '{self.index}' already exists.")
            else:
                raise Exception(f"Unexpected status code: {response.status_code} - {response.text}")

        except Exception as e:
            raise Exception(f"Error creating index: {str(e)}")

    def index_document(self, chunks: List[Dict], s3_path: str, metadata: Dict):
        """Index document chunks in OpenSearch."""
        try:
            # Ensure index exists
            self._create_index_if_not_exists()
            
            bulk_data = []
            for i, chunk in enumerate(chunks):
                # Index action
                action = {
                    "index": {
                        "_index": self.index,
                        "_id": f"{s3_path}_{i}"
                    }
                }
                
                # Document data
                document = {
                    'content': chunk['text'],
                    'embedding': chunk['embedding'],
                    'source': s3_path,
                    'chunk_id': i,
                    'page_number': chunk.get('page_number'),
                    'metadata': metadata
                }
                
                bulk_data.extend([
                    json.dumps(action),
                    json.dumps(document)
                ])

            # Only proceed if there are chunks to index
            if bulk_data:
                bulk_body = '\n'.join(bulk_data) + '\n'
                response = requests.post(
                    self._get_url('_bulk'),
                    auth=self.auth,
                    headers=self._get_headers(),
                    data=bulk_body
                )
                
                if not response.ok:
                    raise Exception(f"Failed to index documents: {response.text}")
                
                # Log success
                self.logger.info(f"Successfully indexed {len(chunks)} chunks for {s3_path}")
            else:
                raise Exception("No chunks to index")
                    
        except Exception as e:
            self.logger.error(f"Error indexing document: {str(e)}")
            raise
    
    def _parse_search_results(self, search_results: dict) -> List[Dict]:
        """Parse and debug search results."""
        try:
            parsed_results = []
            for hit in search_results['hits']['hits']:
                source = hit['_source']
                parsed_results.append({
                    'content': source['content'],
                    'source': source['source'],
                    'page_number': source.get('page_number'),
                    'score': hit['_score'],
                    'metadata': source['metadata']
                })
            return parsed_results
        except KeyError as e:
            self.logger.error(f"KeyError while parsing search results: {str(e)}")
            raise Exception("Error parsing search results.")
    
    def search_chunks(self, query: str, document_path: str = None, k: int = 5) -> List[Dict]:
        """Enhanced search for relevant chunks using hybrid search with better relevance scoring."""
        try:
            query_embedding = self._get_query_embedding(query)
            
            # Enhanced search query with better scoring and filters
            search_body = {
                "size": k,
                "query": {
                    "bool": {
                        "should": [
                            {
                                "multi_match": {
                                    "query": query,
                                    "fields": [
                                        "content^3",         # Boosted text match
                                        "metadata.bank^2",   # Boosted metadata matches
                                        "metadata.year^2",
                                        "metadata.period^2",
                                        "metadata.filename"
                                    ],
                                    "type": "best_fields",
                                    "fuzziness": "AUTO",
                                    "minimum_should_match": "75%"  # Require better matches
                                }
                            },
                            {
                                "knn": {
                                    "embedding": {
                                        "vector": query_embedding,
                                        "k": k
                                    }
                                }
                            }
                        ],
                        "minimum_should_match": 1
                    }
                },
                "_source": {
                    "includes": [
                        "content",
                        "source",
                        "page_number",
                        "metadata",
                        "chunk_id"
                    ]
                },
                "highlight": {
                    "fields": {
                        "content": {
                            "type": "unified",
                            "number_of_fragments": 3,
                            "fragment_size": 150
                        }
                    },
                    "pre_tags": ["<mark>"],
                    "post_tags": ["</mark>"]
                }
            }

            # Add document filter if specified
            if document_path:
                search_body["query"]["bool"]["filter"] = [
                    {"term": {"source": document_path}}
                ]

            # Execute search
            url = f"https://{self.endpoint}/{self.index}/_search"
            response = requests.post(
                url,
                auth=self.auth,
                headers=self._get_headers(),
                data=json.dumps(search_body)
            )

            if not response.ok:
                raise Exception(f"Search failed: {response.text}")

            # Process and enhance results
            search_results = response.json()
            return self._enhance_search_results(search_results, query)

        except Exception as e:
            self.logger.error(f"Error searching chunks: {str(e)}")
            raise

    def _enhance_search_results(self, search_results: dict, query: str) -> List[Dict]:
        """Enhanced parsing of search results with better context and relevance information."""
        try:
            parsed_results = []
            
            for hit in search_results['hits']['hits']:
                source = hit['_source']
                
                # Get highlighted snippets or fall back to content
                highlighted_content = (
                    hit.get('highlight', {})
                    .get('content', [source['content']])[0]
                )

                # Calculate the relevance context
                context_start = max(
                    source['content'].find(highlighted_content.replace('<mark>', '').replace('</mark>', '')) - 100,
                    0
                )
                context_end = min(
                    context_start + len(highlighted_content) + 200,
                    len(source['content'])
                )
                
                # Enhanced result object
                parsed_results.append({
                    'content': source['content'],
                    'context': source['content'][context_start:context_end],
                    'highlighted_content': highlighted_content,
                    'source': source['source'],
                    'page_number': source.get('page_number'),
                    'score': hit['_score'],
                    'metadata': source['metadata'],
                    'chunk_id': source.get('chunk_id'),
                    'relevance_score': self._calculate_relevance_score(
                        query,
                        source['content'],
                        hit['_score']
                    )
                })

            # Sort by relevance score
            parsed_results.sort(key=lambda x: x['relevance_score'], reverse=True)
            
            # Filter out low relevance results
            return [r for r in parsed_results if r['relevance_score'] > 0.3]

        except Exception as e:
            self.logger.error(f"Error parsing search results: {str(e)}")
            raise

    def _calculate_relevance_score(self, query: str, content: str, opensearch_score: float) -> float:
        """Calculate a normalized relevance score."""
        try:
            # Normalize OpenSearch score (typically between 0 and 20)
            normalized_score = min(opensearch_score / 20.0, 1.0)
            
            # Calculate text similarity
            query_words = set(query.lower().split())
            content_words = set(content.lower().split())
            word_overlap = len(query_words.intersection(content_words))
            text_similarity = word_overlap / len(query_words) if query_words else 0
            
            # Combine scores with weights
            final_score = (normalized_score * 0.7) + (text_similarity * 0.3)
            
            return round(final_score, 3)

        except Exception as e:
            self.logger.error(f"Error calculating relevance score: {str(e)}")
            return 0.0

    def _get_query_embedding(self, query: str) -> List[float]:
        """Get embedding for query using Titan model."""
        try:
            bedrock = boto3.client('bedrock-runtime')
            
            response = bedrock.invoke_model(
                modelId='amazon.titan-embed-text-v2:0',
                contentType='application/json',
                accept='application/json',
                body=json.dumps({
                    'inputText': query
                })
            )
            
            response_body = json.loads(response['body'].read().decode())
            return response_body['embedding']
            
        except Exception as e:
            raise Exception(f"Error getting query embedding: {str(e)}")

    def delete_document(self, s3_path: str):
        """Delete all chunks for a document."""
        try:
            response = requests.post(
                self._get_url(f"{self.index}/_delete_by_query"),
                auth=self.auth,
                headers=self._get_headers(),
                data=json.dumps({
                    "query": {
                        "term": {
                            "source": s3_path
                        }
                    }
                })
            )

            if not response.ok:
                raise Exception(f"Delete failed: {response.text}")
                
        except Exception as e:
            raise Exception(f"Error deleting document: {str(e)}")