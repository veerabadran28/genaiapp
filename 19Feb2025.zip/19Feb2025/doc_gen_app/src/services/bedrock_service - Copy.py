import boto3
import json
import logging
from typing import Dict, Optional
from botocore.config import Config

class BedrockService:
    def __init__(self, model_config: Dict):
        """Initialize Bedrock service with model configuration."""
        self.logger = logging.getLogger(__name__)
        self.model_config = model_config
        self.client = self._initialize_client()

    def _initialize_client(self):
        """Initialize Bedrock client with retry configuration."""
        config = Config(
            retries=dict(
                max_attempts=3,
                mode='standard'
            )
        )

        return boto3.client(
            service_name='bedrock-runtime',
            region_name=self.model_config.get('region', 'us-east-1'),
            config=config
        )

    def invoke_model(self, prompt: str) -> Optional[Dict]:
        """Invoke the Bedrock model with the given prompt."""
        try:
            body = json.dumps({
                "anthropic_version": self.model_config['version'],
                "max_tokens": self.model_config['max_tokens'],
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            }
                        ]
                    }
                ],
                "temperature": self.model_config['temperature'],
                "top_p": self.model_config['top_p']
            })

            response = self.client.invoke_model(
                modelId=self.model_config['model_id'],
                body=body,
                contentType='application/json',
                accept='application/json'
            )

            response_body = json.loads(response['body'].read().decode())
            
            if 'content' in response_body:
                content_text = response_body['content'][0]['text']
                content_text = content_text.replace('```json\n', '').replace('\n```', '')
                return json.loads(content_text)
            
            self.logger.error("Unexpected response format")
            return None

        except Exception as e:
            self.logger.error(f"Error invoking model: {str(e)}")
            return None

    def is_healthy(self) -> bool:
        """Check if the service is healthy."""
        try:
            test_prompt = "Test connection"
            response = self.invoke_model(test_prompt)
            return response is not None
        except Exception:
            return False